using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightningAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public GameObject chain;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public int numberOfProjectiles = 2;

    private Vector2 lastPosition;

    public bool augmented = false;

    private bool doneAttacking = false;
    public GameObject gameManager;
    private GameObject enemyToDamage;


    private void FixedUpdate()
    {
        if (!doneAttacking)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
            {
                StartCoroutine(LaunchProjectile());
            }
            else
            {
                gameManager.GetComponent<FindClosestEnemy>().FindEnemy();
            }
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;
        gameManager.GetComponent<FindClosestEnemy>().FindEnemy();

        for (int i = 1; i <= numberOfProjectiles + gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
            {
                int randomEnemy = Random.Range(0, gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length);
                if (gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy] != null)
                {
                    enemyToDamage = gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy].gameObject;

                    GameObject instance = Instantiate(projectile, new Vector2(enemyToDamage.gameObject.transform.position.x, enemyToDamage.gameObject.transform.position.y), projectile.transform.rotation);
                    enemyToDamage.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage;
                    if (enemyToDamage.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
                    {
                        enemyToDamage.GetComponent<EnemyGeneral>().die = true;
                    }
                    else
                    {
                        enemyToDamage.GetComponent<EnemyGeneral>().knockbackForce = knockbackForce;
                        enemyToDamage.GetComponent<EnemyGeneral>().stun = true;
                    }

                    if (augmented)
                    {
                        if (i - 1 > 0)
                        {
                            instance = Instantiate(chain, enemyToDamage.transform.position, transform.rotation);

                            Vector2 direction = lastPosition - (Vector2)enemyToDamage.transform.position;
                            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
                            Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
                            instance.transform.rotation = rotation;

                            instance.GetComponent<Rigidbody2D>().velocity = instance.transform.right * projectileSpeed;
                            instance.GetComponent<LightningChainAttackEvent>().attackDamage = attackDamage;
                            instance.GetComponent<LightningChainAttackEvent>().knockbackForce = knockbackForce;
                            instance.GetComponent<LightningChainAttackEvent>().destinationToBe = lastPosition;
                        }

                        lastPosition = enemyToDamage.transform.position;
                    }

                    yield return new WaitForSeconds(0.06f);
                }
            }
        }

        yield return new WaitForSeconds(attackSpeed);
        doneAttacking = false;
    }
}

