using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScytheExplosion : MonoBehaviour
{
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;
    private void Start()
    {
        StartCoroutine(Destroy());
    }

    IEnumerator Destroy()
    {
        yield return new WaitForSeconds(0.15f);
        GetComponent<Collider2D>().enabled = true;
        yield return new WaitForSeconds(0.45f);
        Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage;
            collision.gameObject.GetComponent<EnemyGeneral>().projectileDirection = transform.position;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            {
                collision.gameObject.GetComponent<EnemyGeneral>().knockbackForce = knockbackForce;
                collision.gameObject.GetComponent<EnemyGeneral>().stun = true;
            }
        }
    }
}
