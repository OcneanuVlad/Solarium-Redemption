using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlasmaAttackEvent : MonoBehaviour
{
    [HideInInspector] public GameObject closestEnemy;
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float projectileSpeed;
    private GameObject secondClosestEnemy;
    [HideInInspector] public bool augmented;
    [HideInInspector] public bool move = true;
    [HideInInspector] public float amountFrozen;

    public GameObject orb;

    private int enemyLayer = 1 << 8;
    public GameObject gameManager;
    private new Rigidbody2D rigidbody;
    private float j = 10;

    private int enemiesHit = 0;
    [HideInInspector] public int maxEnemiesHit;

    private void Start()
    {
        StartCoroutine(WaitUntilMove());
        rigidbody = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        if (move)
        {
            if (closestEnemy == null)
            {
                FindEnemy();
            }
            else
            {
                rigidbody.velocity = (new Vector3(closestEnemy.transform.position.x, closestEnemy.transform.position.y + 0.1f) - transform.position).normalized * (projectileSpeed + gameManager.GetComponent<AttackStats>().projectileSpeed * projectileSpeed);
            }
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {

        if (collision.gameObject == closestEnemy)
        {
            if (augmented)
            {
                for (int i = 1; i <= 2; i++)
                {
                    GameObject instance = Instantiate(orb, transform.position, transform.rotation);
                    instance.GetComponent<PlasmaAttackEvent>().attackDamage = attackDamage;
                    instance.GetComponent<PlasmaAttackEvent>().move = false;
                    if (i == 1)
                    {
                        instance.GetComponent<PlasmaAttackEvent>().closestEnemy = null;
                        instance.GetComponent<Rigidbody2D>().velocity = transform.up * projectileSpeed;
                    }
                    else
                    {
                        instance.GetComponent<PlasmaAttackEvent>().closestEnemy = null;
                        instance.GetComponent<Rigidbody2D>().velocity = -transform.up * projectileSpeed;
                    }
                    instance.GetComponent<PlasmaAttackEvent>().projectileSpeed = projectileSpeed;
                    instance.GetComponent<PlasmaAttackEvent>().maxEnemiesHit = 1;
                    instance.GetComponent<PlasmaAttackEvent>().augmented = false;
                    instance.GetComponent<PlasmaAttackEvent>().amountFrozen = amountFrozen;
                    instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
                }
            }

            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage + gameManager.GetComponent<AttackStats>().attackDamage * attackDamage;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            {
                collision.gameObject.GetComponent<EnemyGeneral>().amountFrozen = amountFrozen;
                collision.gameObject.GetComponent<EnemyGeneral>().Freeze();
            }

            enemiesHit++;
            if (enemiesHit >= maxEnemiesHit)
            {
                Destroy(gameObject);
            }
            else
            {
                FindEnemy();
            }
        }
        else
        {
            if (collision.gameObject.CompareTag("EnemyHitBox"))
            {
                collision.gameObject.GetComponent<EnemyGeneral>().amountFrozen = amountFrozen;
                collision.gameObject.GetComponent<EnemyGeneral>().Freeze();
            }
        }
    }

    private void FindEnemy()
    {
        closestEnemy = null;
     

        Collider2D[] allEnemies = Physics2D.OverlapCircleAll(transform.position, Mathf.Abs(transform.position.x - (new Vector2(j, 0)).x), enemyLayer);
        while (allEnemies.Length > 8 && j >= 5)
        {
            j -= 0.1f;
            allEnemies = Physics2D.OverlapCircleAll(transform.position, Mathf.Abs(transform.position.x - (new Vector2(j, 0)).x), enemyLayer);
        }
        while (allEnemies.Length < 8 && j < 10)
        {
            j += 0.1f;
            allEnemies = Physics2D.OverlapCircleAll(transform.position, Mathf.Abs(transform.position.x - (new Vector2(j, 0)).x), enemyLayer);
        }

        closestEnemy = allEnemies[Random.Range(0, allEnemies.Length)].gameObject;
    }

    IEnumerator WaitUntilMove()
    {
        yield return new WaitForSeconds(1);
        move = true;
    }

}
