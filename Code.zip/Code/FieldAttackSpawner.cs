using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FieldAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public float shrink;
    public bool augmented;
    public float scale;

    private bool doneAttacking = false;
    public GameObject gameManager;
    private GameObject enemyToDamage;


    private void FixedUpdate()
    {
        if (!doneAttacking)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
            {
                StartCoroutine(LaunchProjectile());
            }
            else
            {
                gameManager.GetComponent<FindClosestEnemy>().FindEnemy();
            }
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;
        gameManager.GetComponent<FindClosestEnemy>().FindEnemy();

        for (int i = 1; i <= 1 + gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
            {
                int randomEnemy = Random.Range(0, gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length);
                if (gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy] != null)
                {
                    enemyToDamage = gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy].gameObject;
                    Vector2 direction = enemyToDamage.transform.position - transform.position;
                    float angle = Mathf.Atan2(direction.y + 0.5f, direction.x) * Mathf.Rad2Deg;
                    Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
                    transform.rotation = rotation;

                    GameObject instance = Instantiate(projectile, transform.position, transform.rotation);
                    instance.GetComponent<FieldAttackEvent>().attackDamage = attackDamage;
                    instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
                    if (augmented)
                    {
                        instance.transform.localScale -= new Vector3(instance.transform.localScale.x / 3, instance.transform.localScale.y / 3);
                    }
                    instance.GetComponent<FieldAttackEvent>().shrink = shrink;
                    instance.GetComponent<FieldAttackEvent>().augmented = augmented;
                    instance.GetComponent<Rigidbody2D>().velocity = instance.transform.right * projectileSpeed;
                    instance.transform.localScale = new Vector3(scale, scale, 1);
                }
            }
            yield return new WaitForSeconds(0.45f);
        }

        yield return new WaitForSeconds(attackSpeed);
        doneAttacking = false;
    }
}

