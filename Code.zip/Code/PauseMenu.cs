using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public Text text1;
    public Text text2;
    public Text text3;
    public Text text4;
    public Text text5;
    public Text text6;
    public Text text7;

    [HideInInspector] public bool pause;

    public GameObject pauseMenu;

    public GameObject weapons;

    public GameObject crosshair;

    private void Update()
    {
        crosshair.transform.position = Input.mousePosition;

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (!pause)
            {
                if (!GetComponent<UpgradeBoxPopUp>().isOpen)
                {
                    Text3MouseOverExit();
                    Text2MouseOverExit();
                    Text1MouseOverExit();

                    weapons.transform.localScale = new Vector3(1.4f, 1.4f);
                    pauseMenu.SetActive(true);
                    Time.timeScale = 0;
                    pause = true;
                }
            }
            else
            {
                Text3MouseOverExit();
                Text2MouseOverExit();
                Text1MouseOverExit();

                weapons.transform.localScale = new Vector3(1, 1);
                pauseMenu.SetActive(false);
                Time.timeScale = 1;
                pause = false;
            }
        }
    }

    private void FixedUpdate()
    {
        if (pause || GetComponent<UpgradeBoxPopUp>().isOpen)
        {
            crosshair.SetActive(false);
        }
        else
        {
            crosshair.SetActive(true);
        }
    }

    public void ExitPause()
    {
        weapons.transform.localScale = new Vector3(1, 1);
        pauseMenu.SetActive(false);
        Time.timeScale = 1;
        pause = false;
    }

    public void Exit()
    {
        Time.timeScale = 1;
        GetComponent<UpgradeBoxPopUp>().isOpen = true;
        SceneManager.LoadScene("Start Menu");
    }

    public void Text1MouseOverEnter()
    {
        text1.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text1MouseOverExit()
    {
        text1.color = new Color(0, 0, 0.08f);
    }

    public void Text2MouseOverEnter()
    {
        text2.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text2MouseOverExit()
    {
        text2.color = new Color(0, 0, 0.08f);
    }

    public void Text3MouseOverEnter()
    {
        text3.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text3MouseOverExit()
    {
        text3.color = new Color(0, 0, 0.08f);
    }

    public void Text4MouseOverEnter()
    {
        text4.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text4MouseOverExit()
    {
        text4.color = new Color(0, 0, 0.08f);
    }

    public void Text5MouseOverEnter()
    {
        text5.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text5MouseOverExit()
    {
        text5.color = new Color(0, 0, 0.08f);
    }
    public void Text6MouseOverEnter()
    {
        text6.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text6MouseOverExit()
    {
        text6.color = new Color(0, 0, 0.08f);
    }
    public void Text7MouseOverEnter()
    {
        text7.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text7MouseOverExit()
    {
        text7.color = new Color(0, 0, 0.08f);
    }
}
