using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ActiveRocketAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public GameObject pointUp;
    public GameObject pointDown;
    private float cooldown = 0;
    public float cooldownDuration;
    public int numberOfProjectiles;
    public float scale;

    public bool augmented;

    private Vector3 destination;

    public GameObject gameManager;
    public Image cooldownImage;


    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0) && cooldown >= cooldownDuration)
        {
            destination = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            StartCoroutine(LaunchProjectile());
            cooldown = 0;
        }
        if (cooldown < cooldownDuration)
        {
            cooldown += Time.deltaTime;
        }

        cooldownImage.fillAmount = cooldown / cooldownDuration;

        Vector2 direction = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        transform.rotation = rotation;
    }



    IEnumerator LaunchProjectile()
    {

        for (int i = 1; i <= numberOfProjectiles + gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            GameObject instance = Instantiate(projectile, transform.position, transform.rotation);
            if (augmented)
            {
                instance.GetComponent<ActiveRocketAttackEvent>().destination2 = (Vector2)destination + Random.insideUnitCircle * 4;
            }
            else
            {
                instance.GetComponent<ActiveRocketAttackEvent>().destination2 = (Vector2)destination;
            }
            if (i % 2 == 0)
            {
                instance.GetComponent<ActiveRocketAttackEvent>().destination1 = pointDown.transform.position;
                instance.GetComponent<Rigidbody2D>().velocity = (pointDown.transform.position - transform.position).normalized * 2;
            }
            else
            {
                instance.GetComponent<ActiveRocketAttackEvent>().destination1 = pointUp.transform.position;
                instance.GetComponent<Rigidbody2D>().velocity = (pointUp.transform.position - transform.position).normalized * 2;
            }
            instance.GetComponent<ActiveRocketAttackEvent>().attackDamage = attackDamage;
            instance.GetComponent<ActiveRocketAttackEvent>().knockbackForce = knockbackForce;
            instance.GetComponent<ActiveRocketAttackEvent>().projectileSpeed = projectileSpeed;
            instance.transform.localScale = new Vector3(scale, scale, 1);
            instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
            yield return new WaitForSeconds(0.25f);
        }
    }
}

