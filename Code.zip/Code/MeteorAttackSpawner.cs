using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteorAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public GameObject shadow;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public bool augmented;
    public float scale;

    private bool doneAttacking = false;
    public GameObject gameManager;
    private GameObject enemyToDamage;



    private void FixedUpdate()
    {
        if (!doneAttacking)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
            {
                StartCoroutine(LaunchProjectile());
            }
            else
            {
                gameManager.GetComponent<FindClosestEnemy>().FindEnemy();
            }
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;
        int i;
        gameManager.GetComponent<FindClosestEnemy>().FindEnemy();

        for (i = 1; i <= 1 + gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
            {
                int randomEnemy = Random.Range(0, gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length);
                if (gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy] != null)
                {
                    enemyToDamage = gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy].gameObject;

                    GameObject instance = Instantiate(projectile, new Vector2(Random.Range(Camera.main.ViewportToWorldPoint(new Vector3(0, 0, 0)).x, Camera.main.ViewportToWorldPoint(new Vector3(1, 0, 0)).x), Camera.main.ViewportToWorldPoint(new Vector2(0, 1.2f)).y), projectile.transform.rotation);
                    instance.GetComponent<MeteorAttackEvent>().destination = enemyToDamage.transform.position;
                    instance.GetComponent<MeteorAttackEvent>().attackDamage = attackDamage;
                    instance.GetComponent<MeteorAttackEvent>().knockbackForce = knockbackForce;
                    instance.GetComponent<MeteorAttackEvent>().augmented = augmented;
                    instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
                    instance.GetComponent<MeteorAttackEvent>().projectileSpeed = projectileSpeed;
                    instance.transform.localScale = new Vector3(scale, scale);

                    GameObject meteor = instance;
                    float xPosition = instance.transform.position.x;
                    instance = Instantiate(shadow, new Vector3(xPosition, enemyToDamage.transform.position.y), shadow.transform.rotation);
                    instance.GetComponent<ShadowFollow>().destination = enemyToDamage.transform.position;
                    instance.GetComponent<ShadowFollow>().meteor = meteor;
                    yield return new WaitForSeconds(0.45f);
                }
            }
        }

        yield return new WaitForSeconds(attackSpeed);
        doneAttacking = false;
    }
}

