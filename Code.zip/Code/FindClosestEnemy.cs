using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FindClosestEnemy : MonoBehaviour
{
    public GameObject player;

    [HideInInspector] public Collider2D[] allEnemies;
    [HideInInspector] public GameObject closestEnemy;

    private int enemyLayer = 1 << 8;

    float j = 0.9f;

    private void Start()
    {
        player = GameObject.Find("Player");
        FindEnemy();
    }

    void Update()
    {
        
    }

    public void FindEnemy()
    {
        float distanceToClosestEnemy = Mathf.Infinity;
        closestEnemy = null;

        allEnemies = Physics2D.OverlapCircleAll(player.transform.position, Mathf.Abs(player.transform.position.x - Camera.main.ViewportToWorldPoint(new Vector2(j, 0)).x), enemyLayer);
        while (allEnemies.Length > 75 && j >= 0.1f)
        {
            j -= 0.1f;
            allEnemies = Physics2D.OverlapCircleAll(player.transform.position, Mathf.Abs(player.transform.position.x - Camera.main.ViewportToWorldPoint(new Vector2(j, 0)).x), enemyLayer);
        }
        while (allEnemies.Length < 75 && j < 0.8f)
        {
            j += 0.1f;
            allEnemies = Physics2D.OverlapCircleAll(player.transform.position, Mathf.Abs(player.transform.position.x - Camera.main.ViewportToWorldPoint(new Vector2(j, 0)).x), enemyLayer);
        }
        if (allEnemies.Length == 0)
        {
            allEnemies = Physics2D.OverlapCircleAll(player.transform.position, Mathf.Abs(player.transform.position.x - Camera.main.ViewportToWorldPoint(new Vector2(2, 0)).x), enemyLayer);
        }


        for (int i = 0; i < allEnemies.Length; i++)
        { 

            float distanceToEnemy = (allEnemies[i].transform.position - player.transform.position).sqrMagnitude;
            if (distanceToEnemy < distanceToClosestEnemy)
            {
                distanceToClosestEnemy = distanceToEnemy;
                closestEnemy = allEnemies[i].gameObject;
            }
        }
    }
}
