using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerHealth : MonoBehaviour
{
    [HideInInspector] public float currentHealth = 100;
    [HideInInspector] public float maxHealth = 100;
    public Image healthImage;
    public Animator playerAnimator;

    [HideInInspector] public bool dead;

    public RuntimeAnimatorController animator1;
    public RuntimeAnimatorController animator2;
    public RuntimeAnimatorController animator3;

    public GameObject gameManager;
    public GameObject deathScreen;

    [HideInInspector] public float healRegen = 0;

    private void Start()
    {
        if (GameObject.Find("MenuManager").GetComponent<MainManager>().costume == 1)
        {
            transform.GetChild(4).GetChild(0).GetComponent<Animator>().runtimeAnimatorController = animator1;
        }

        if (GameObject.Find("MenuManager").GetComponent<MainManager>().costume == 2)
        {
            transform.GetChild(4).GetChild(0).GetComponent<Animator>().runtimeAnimatorController = animator2;
        }

        if (GameObject.Find("MenuManager").GetComponent<MainManager>().costume == 3)
        {
            transform.GetChild(4).GetChild(0).GetComponent<Animator>().runtimeAnimatorController = animator3;
        }
    }

    void Update()
    {
        if (currentHealth > 0)
        {
            healthImage.GetComponent<Image>().fillAmount = currentHealth / maxHealth;
        }
    }

    private void FixedUpdate()
    {
        if (healRegen > 0)
        {
            currentHealth += healRegen * Time.deltaTime;
        }

        if (currentHealth <= 0)
        {
            StartCoroutine(WaitBeforeDestroy());
        }
    }

    IEnumerator WaitBeforeDestroy()
    {
        dead = true;
        playerAnimator.SetBool("IsDead", true);
        transform.GetChild(3).gameObject.SetActive(false);
        transform.GetChild(2).gameObject.SetActive(false);
        transform.GetChild(1).localScale = new Vector3(2.5f, 2.5f, 1);
        transform.GetChild(0).gameObject.SetActive(false);
        GetComponent<PlayerMovement>().enabled = false;
        GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeAll;
        yield return new WaitForSecondsRealtime(3f);
        deathScreen.SetActive(true);
        gameManager.GetComponent<UpgradeBoxPopUp>().isOpen = true;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            collision.gameObject.GetComponentInParent<EnemyGeneral>().isAttacking = true;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            collision.gameObject.GetComponentInParent<EnemyGeneral>().isAttacking = false;
        }
    }
}
