using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RayAttackSpawner : MonoBehaviour
{
    public bool augmented;
    void Update()
    {
        if (!augmented)
        {
            Vector2 direction = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            transform.rotation = Quaternion.Slerp(transform.rotation, rotation, 0.05f);
        }
        else
        {
            transform.Rotate(0, 0, 25 * Time.deltaTime);
        }
    }
}
