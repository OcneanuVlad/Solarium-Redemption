using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwordAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public bool isUpgraded = false;
    public bool augmented = false;

    private bool doneAttacking = false;
    public GameObject gameManager;

    private GameObject sword1;
    private GameObject sword2;
    private GameObject pivot1;
    private GameObject pivot2;

    public GameObject flyingSword1;

    private Animator pivot1Animator;
    private Animator pivot2Animator;

    private float previousSize;

    void Start()
    {
        previousSize = gameManager.GetComponent<AttackStats>().projectileSize;

        pivot1 = transform.GetChild(0).gameObject;
        pivot2 = transform.GetChild(1).gameObject;
        sword1 = pivot1.transform.GetChild(0).gameObject;
        sword2 = pivot2.transform.GetChild(0).gameObject;

        pivot1Animator = pivot1.GetComponent<Animator>();
        pivot2Animator = pivot2.GetComponent<Animator>();
    }

    private void FixedUpdate()
    {
        if (gameManager.GetComponent<AttackStats>().projectileSize != previousSize)
        {
            transform.localScale += new Vector3((gameManager.GetComponent<AttackStats>().projectileSize - previousSize) / 100 * transform.localScale.x, (gameManager.GetComponent<AttackStats>().projectileSize - previousSize) / 100 * transform.localScale.y, 0);
            previousSize = gameManager.GetComponent<AttackStats>().projectileSize;
        }

        if (!doneAttacking)
        {
            StartCoroutine(LaunchProjectile());
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;

        sword1.GetComponent<SwordAttackEvent>().attackDamage = attackDamage;
        sword1.GetComponent<SwordAttackEvent>().knockbackForce = knockbackForce;
        sword2.GetComponent<SwordAttackEvent>().attackDamage = attackDamage;
        sword2.GetComponent<SwordAttackEvent>().knockbackForce = knockbackForce;

        sword1.SetActive(true);
        pivot1Animator.SetBool("FirstSlash", true);
        yield return new WaitForSeconds(1f / 3 + 0.03f);
        pivot1Animator.SetBool("FirstSlash", false);
        sword1.SetActive(false);
        yield return new WaitForSeconds(0.01f);


        if (gameManager.GetComponent<AttackStats>().numberOfProjectiles == 1)
        {
            sword1.SetActive(true);
            pivot1Animator.SetBool("SecondSlash", true);
            yield return new WaitForSeconds(1f / 3 + 0.03f);
            pivot1Animator.SetBool("SecondSlash", false);
            sword1.SetActive(false);
            yield return new WaitForSeconds(0.01f);
        }

        if (gameManager.GetComponent<AttackStats>().numberOfProjectiles == 2)
        {
            sword1.SetActive(true);
            pivot1Animator.SetBool("SecondSlash", true);
            yield return new WaitForSeconds(1f / 3 + 0.03f);
            pivot1Animator.SetBool("SecondSlash", false);
            sword1.SetActive(false);
            yield return new WaitForSeconds(0.01f);

            sword1.SetActive(true);
            sword2.SetActive(true);
            pivot1Animator.SetBool("ThirdSlash", true);
            pivot2Animator.SetBool("FirstSlash", true);
            yield return new WaitForSeconds(1f / 3 + 0.03f);
            pivot1Animator.SetBool("ThirdSlash", false);
            pivot2Animator.SetBool("FirstSlash", false);
            sword2.SetActive(false);
            sword1.SetActive(false);
            yield return new WaitForSeconds(0.01f);
        }

        if (isUpgraded)
        {
            sword1.SetActive(true);
            sword2.SetActive(true);
            pivot1Animator.SetBool("FourthSlash", true);
            pivot2Animator.SetBool("SecondSlash", true);
            yield return new WaitForSeconds(1f / 3 + 0.03f);
            pivot1Animator.SetBool("FourthSlash", false);
            pivot2Animator.SetBool("SecondSlash", false);
            sword2.SetActive(false);
            sword1.SetActive(false);
            yield return new WaitForSeconds(0.01f);
        }

        if (augmented)
        {
            GameObject instance = Instantiate(flyingSword1, transform.position, Quaternion.Euler(0, 0, Random.Range(0, 180)));
            instance.GetComponentInChildren<SwordAttackEvent>().attackDamage = attackDamage;
            instance.GetComponentInChildren<SwordAttackEvent>().knockbackForce = knockbackForce;
            instance.GetComponentInChildren<SwordAttackEvent>().isFlyingSword = true;
            instance.GetComponent<FlyingSwordAttackEvent>().projectileSpeed = projectileSpeed;
            instance.GetComponent<FlyingSwordAttackEvent>().turningPoint = instance.transform.GetChild(1).gameObject;
            instance.GetComponent<Rigidbody2D>().velocity = instance.transform.right * projectileSpeed;
            instance.GetComponent<FlyingSwordAttackEvent>().player = gameObject;
            instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);

            instance = Instantiate(flyingSword1, transform.position, Quaternion.Euler(0, 0, Random.Range(180, 360)));
            instance.GetComponentInChildren<SwordAttackEvent>().attackDamage = attackDamage;
            instance.GetComponentInChildren<SwordAttackEvent>().knockbackForce = knockbackForce;
            instance.GetComponentInChildren<SwordAttackEvent>().isFlyingSword = true;
            instance.GetComponent<FlyingSwordAttackEvent>().projectileSpeed = projectileSpeed;
            instance.GetComponent<FlyingSwordAttackEvent>().turningPoint = instance.transform.GetChild(1).gameObject;
            instance.GetComponent<Rigidbody2D>().velocity = instance.transform.right * projectileSpeed;
            instance.GetComponent<FlyingSwordAttackEvent>().player = gameObject;
            instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
        }

        yield return new WaitForSeconds(attackSpeed - gameManager.GetComponent<AttackStats>().attackSpeed * attackSpeed - 0.1f);
        doneAttacking = false;
    }
}

