using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interface : MonoBehaviour
{
    [HideInInspector] public int upgradePoints = 0;
    [HideInInspector] public bool isInUpgradeBox = false;
}
