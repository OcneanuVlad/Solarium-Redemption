using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FieldAttackEvent : MonoBehaviour
{
    private Vector3 positionInCamera;
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float shrink;
    [HideInInspector] public bool augmented;
    private Vector3 originalSize;
    public GameObject explosion;

    private bool givingDamage;
    private List<GameObject> enemiesInField;

    private void Start()
    {
        originalSize = transform.localScale;
        enemiesInField = new List<GameObject>();
    }
    void Update()
    {
        positionInCamera = Camera.main.WorldToViewportPoint(transform.position);
        if (positionInCamera.x < -0.2f || positionInCamera.x > 1.2f || positionInCamera.y < -0.2 || positionInCamera.y > 1.2)
        {
            Destroy(gameObject);
        }
    }

    private void FixedUpdate()
    {
        transform.Rotate(0, 0, 50 * Time.deltaTime);

        if (enemiesInField.Count > 0)
        {
            if (!givingDamage)
            {
                for (int i = 0; i < enemiesInField.Count; i++)
                {
                    StartCoroutine(DamageEnemies(enemiesInField[i]));
                }
            }
        }

        if (augmented)
        {
            transform.localScale += new Vector3(shrink * enemiesInField.Count, shrink * enemiesInField.Count) * Time.deltaTime;
            if (transform.localScale.x > originalSize.x * 2)
            {
                GetComponent<Rigidbody2D>().velocity = Vector3.zero;
                GameObject instance = Instantiate(explosion, transform.position, transform.rotation);
                instance.transform.localScale += new Vector3(instance.transform.localScale.x * 0.5f, instance.transform.localScale.y * 0.5f);
                instance.GetComponent<ScytheExplosion>().attackDamage = attackDamage * 7;
                instance.GetComponent<ScytheExplosion>().knockbackForce = 1000;
                Destroy(gameObject);
            }
        }
        else
        {
            transform.localScale -= new Vector3(shrink * enemiesInField.Count, shrink * enemiesInField.Count) * Time.deltaTime;
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            if (!enemiesInField.Contains(collision.gameObject))
            {
                enemiesInField.Add(collision.gameObject);
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            if (enemiesInField != null && enemiesInField.Contains(collision.gameObject))
            {
                enemiesInField.Remove(collision.gameObject);
            }
        }
        
    }

    IEnumerator DamageEnemies(GameObject enemy)
    {
        givingDamage = true;
        enemy.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage;
        if (enemy.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
        {
            enemy.gameObject.GetComponent<EnemyGeneral>().die = true;
        }
        else
        {
            enemy.gameObject.GetComponent<EnemyGeneral>().stun = true;
        }
        yield return new WaitForSecondsRealtime(0.2f);
        givingDamage = false;
    }
}
