using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RocketAttackEvent : MonoBehaviour
{
    private Vector3 positionInCamera;
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;
    [HideInInspector] public float projectileSpeed;
    [HideInInspector] public GameObject destination;
    [HideInInspector] public bool augmented;
    public Sprite augmentedRocket;

    public GameObject explosion;
    public GameObject layer2;
    public GameObject layer21;
    public GameObject layer3;
    public GameObject layer31;
    public GameObject layer32;

    private bool destroying = false;

    private void Start()
    {
        if (augmented)
        {
            GetComponent<SpriteRenderer>().sprite = augmentedRocket;
        }
    }

    void FixedUpdate()
    {
        positionInCamera = Camera.main.WorldToViewportPoint(transform.position);
        if (positionInCamera.x < -0.4f || positionInCamera.x > 1.4f || positionInCamera.y < -0.4f || positionInCamera.y > 1.4f)
        {
            Destroy(gameObject);
        }

        if (destination != null)
        {
            if (Vector2.Distance(transform.position, destination.transform.position) < 0.7f && !destroying)
            {

                StartCoroutine(WaitBeforeDestroy());
            }
            if (!destroying)
            {
                Vector2 direction = destination.transform.position - transform.position;
                float angle = Mathf.Atan2(direction.y + 0.5f, direction.x) * Mathf.Rad2Deg;
                Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
                transform.rotation = rotation;

                GetComponent<Rigidbody2D>().velocity = transform.right * projectileSpeed;
            }
        }
        else
        {
            if (!destroying)
            {
                StartCoroutine(WaitBeforeDestroy());
            }
        }
    }

    IEnumerator WaitBeforeDestroy()
    {
        destroying = true;
        GetComponent<SpriteRenderer>().enabled = false;
        GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezePositionY | RigidbodyConstraints2D.FreezeRotation | RigidbodyConstraints2D.FreezePositionX;
        GameObject instance = Instantiate(explosion, transform.position, transform.rotation);
        instance.GetComponent<DespawnExplosion>().attackDamage = attackDamage;
        instance.transform.localScale = transform.localScale * 3.2f;
        yield return new WaitForSecondsRealtime(0.25f);
        if (augmented)
        {
            instance = Instantiate(explosion, layer2.transform.position, transform.rotation);
            instance.GetComponent<DespawnExplosion>().attackDamage = attackDamage;
            instance.transform.localScale = transform.localScale * 3.2f;
            instance = Instantiate(explosion, layer21.transform.position, transform.rotation);
            instance.GetComponent<DespawnExplosion>().attackDamage = attackDamage;
            instance.transform.localScale = transform.localScale * 3.2f;
            yield return new WaitForSecondsRealtime(0.25f);
            instance = Instantiate(explosion, layer3.transform.position, transform.rotation);
            instance.GetComponent<DespawnExplosion>().attackDamage = attackDamage;
            instance.transform.localScale = transform.localScale * 3.2f;
            instance = Instantiate(explosion, layer31.transform.position, transform.rotation);
            instance.GetComponent<DespawnExplosion>().attackDamage = attackDamage;
            instance.transform.localScale = transform.localScale * 3.2f;
            instance = Instantiate(explosion, layer32.transform.position, transform.rotation);
            instance.GetComponent<DespawnExplosion>().attackDamage = attackDamage;
            instance.transform.localScale = transform.localScale * 3.2f;
            yield return new WaitForSecondsRealtime(0.25f);
        }
        Destroy(gameObject);
    }
}
