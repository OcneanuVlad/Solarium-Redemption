using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    private float countdown = 1;

    public int maxEnemiesSpawned;
    public int minEnemiesSpawned;
    public float spawnCooldown;
    private int previousMinutes;

    public GameObject[] enemyList;
    private List<GameObject> enemies;
    private int index;
    public GameObject gameManager;

    [HideInInspector] public int enemiesSpawned = 0;

    private void Start()
    {
        enemies = new List<GameObject>();
        enemies.Add(enemyList[0]);

        for (int i = 0; i < 12; i++)
        {
            index = Random.Range(0, enemies.Count);
            Instantiate(enemies[index], (Vector2)transform.position + Random.insideUnitCircle.normalized * 8, enemies[index].transform.rotation);
        }
    }

    private void FixedUpdate()
    {
        if (countdown > 0)
        {
            countdown -= Time.deltaTime;
        }

        if (countdown <= 0 && enemiesSpawned < 900)
        {
            StartCoroutine(WaitBetweenWaves());

            countdown = spawnCooldown;
        }

        if (gameManager.GetComponent<Timer>().minutesSurvived != previousMinutes)
        {
            previousMinutes = gameManager.GetComponent<Timer>().minutesSurvived;
            spawnCooldown -= 0.2f;
            maxEnemiesSpawned++;
            minEnemiesSpawned = (int)(maxEnemiesSpawned - (25f / 100f) * maxEnemiesSpawned);
        }

        switch(gameManager.GetComponent<Timer>().minutesSurvived)
        {
            case 3:
                enemies.Add(enemyList[0]);
                enemies.Add(enemyList[1]);
                break;
            case 6:
                enemies.Remove(enemyList[0]);
                enemies.Remove(enemyList[0]);
                break;
            case 9:
                enemies.Add(enemyList[1]);
                enemies.Add(enemyList[2]);
                break;
            case 12:
                enemies.Remove(enemyList[1]);
                enemies.Remove(enemyList[1]);
                break;
            case 15:
                enemies.Add(enemyList[0]);
                enemies.Add(enemyList[1]);
                maxEnemiesSpawned = 40;
                minEnemiesSpawned = 40;
                spawnCooldown = 0.5f;
                break;
        }

        //Debug.Log(enemiesSpawned);
    }

    private void SpawnEnemies(float minX, float maxX, float minY, float maxY)
    {
        index = Random.Range(0, enemies.Count);
        int numberOfEnemies = Random.Range(minEnemiesSpawned, maxEnemiesSpawned + 1);
        for (int i = 1; i <= numberOfEnemies; i++)
        {
            Vector2 positionToSpawn = new Vector2(Random.Range(Camera.main.ViewportToWorldPoint(new Vector3(minX, 0, 0)).x, Camera.main.ViewportToWorldPoint(new Vector3(maxX, 0, 0)).x), Random.Range(Camera.main.ViewportToWorldPoint(new Vector3(0, minY, 0)).y, Camera.main.ViewportToWorldPoint(new Vector3(0, maxY, 0)).y));
            Instantiate(enemies[index], positionToSpawn, enemies[index].transform.rotation);
            enemiesSpawned++;
        }
    }

    IEnumerator WaitBetweenWaves()
    {
        SpawnEnemies(-0.5f, -0.1f, 0.5f, 1f); // left up
        yield return new WaitForSecondsRealtime(0.2f);
        SpawnEnemies(-0.5f, -0.1f, 0f, 0.5f); // left down
        yield return new WaitForSecondsRealtime(0.2f);
        SpawnEnemies(1.1f, 1.5f, 0.5f, 1f); // right up
        yield return new WaitForSecondsRealtime(0.2f);
        SpawnEnemies(1.1f, 1.5f, 0f, 0.5f); // right down
        yield return new WaitForSecondsRealtime(0.2f);
        SpawnEnemies(-0.5f, 0.5f, 1.1f, 1.5f); // up left
        yield return new WaitForSecondsRealtime(0.2f);
        SpawnEnemies(0.5f, 1.5f, 1.1f, 1.5f); // up right
        yield return new WaitForSecondsRealtime(0.2f);
        SpawnEnemies(-0.5f, 0.5f, -0.5f, -0.1f); // down left
        yield return new WaitForSecondsRealtime(0.2f);
        SpawnEnemies(0.5f, 1.5f, -0.5f, -0.1f); // down right
        yield return new WaitForSecondsRealtime(0.2f);
    }
}
