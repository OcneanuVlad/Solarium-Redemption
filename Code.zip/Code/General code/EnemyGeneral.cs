using System.Collections;
using System.Collections.Generic;
using UnityEngine; 

public class EnemyGeneral : MonoBehaviour
{
    // general things
    public float maxEnemyHealth;
    [HideInInspector] public float currentEnemyHealth;
    [HideInInspector] public GameObject player;
    public SpriteRenderer enemySprite;
    public Animator enemyAnimator;
    public Animator shadowAnimator;
    [HideInInspector] public Rigidbody2D enemyRigidbody;

    // despawn
    private float distanceRelativeToCameraX;
    private float distanceRelativeToCameraY;

    // movement
    [SerializeField] private float enemyMovementSpeed;
    [HideInInspector] public Transform playerTarget;
    [HideInInspector] public bool justGotHit = false;
    [HideInInspector] public bool stun = false;
    [HideInInspector] public bool die = false;
    private bool startedDying = false;
    private Vector2 directionToKnockback;
    [HideInInspector] public float knockbackForce;
    private bool gotPushed;
    [HideInInspector] public bool frozen = false;
    [HideInInspector] public float amountFrozen;

    public float attackDamage;
    [HideInInspector] public bool isAttacking;

    [HideInInspector] public Vector2 projectileDirection;
    // drops
    //[HideInInspector] public int upgradeDropped;
    //[SerializeField] private GameObject UpgradeIcon;
    public float droppedXP_amount;
    [SerializeField] private GameObject XPIcon;
    private GameObject droppedXP_object;
    public float chanceToDropXP;


    void Start()
    {
        currentEnemyHealth = maxEnemyHealth;

        distanceRelativeToCameraX = Mathf.Abs(Camera.main.ViewportToWorldPoint(new Vector3(0.5f, 0, 0)).x - Camera.main.ViewportToWorldPoint(new Vector3(1.7f, 0, 0)).x);
        distanceRelativeToCameraY = Mathf.Abs(Camera.main.ViewportToWorldPoint(new Vector3(0, 0.5f, 0)).y - Camera.main.ViewportToWorldPoint(new Vector3(0, 1.7f, 0)).y);
        
        player = GameObject.Find("Player");

        playerTarget = player.transform;
        enemyRigidbody = GetComponentInChildren<Rigidbody2D>();
    }

    void Update()
    {

        // Sprite turning in the direction of the player
        if (!frozen)
        {
            if (transform.position.x > playerTarget.position.x)
            {
                transform.rotation = Quaternion.Euler(0, 0, 0);
            }

            if (transform.position.x < playerTarget.position.x)
            {
                transform.rotation = Quaternion.Euler(0, 180, 0);
            }

            if (isAttacking)
            {
                player.GetComponent<PlayerHealth>().currentHealth -= (attackDamage - player.GetComponent<UpgradesList>().damageReduction / 100 * attackDamage) * Time.deltaTime;
            }
        }
    }

    private void FixedUpdate()
    {
        // Movement
        if (!gotPushed && !frozen)
        {
            enemyRigidbody.velocity = ((playerTarget.position - transform.position).normalized * enemyMovementSpeed);
        }

        // Despawn enemy if too far
        if (Mathf.Abs(player.transform.position.x - transform.position.x) > distanceRelativeToCameraX || Mathf.Abs(player.transform.position.y - transform.position.y) > distanceRelativeToCameraY)
        {
            player.GetComponent<EnemySpawner>().enemiesSpawned--;
            Destroy(gameObject);
        }

        if (die && !startedDying)
        {
            StartCoroutine(WaitBeforeDestroy());
        }

        if (stun)
        {
            StartCoroutine(WaitBeforeMoving());
        }
    }

/*    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Attack") && !isDead)
        {
            // Cannot predict wich OnTrigger will execute first, this or the attack collider, so the damage take instance is done on both parts
            if (!justGotHit)
            {
                justGotHit = true;
                currentEnemyHealth -= other.gameObject.GetComponent<AttackEvent>().attackDamage;
                StartCoroutine(WaitForEndOfFrame());
            }
            

            // check if dead
            if (currentEnemyHealth <= 0)
            {
                isDead = true;
                Destroy(GetComponent<Collider2D>());
                StartCoroutine(WaitBeforeDestroy());
            }
            else
            {
                // if not, stun and play animation
                directionToKnockback = (transform.position - player.transform.position).normalized;
                enemyRigidbody.AddForce(directionToKnockback * 700f);
                StartCoroutine(WaitBeforeMoving());
            }

            

        }
    }*/

    IEnumerator WaitBeforeDestroy()
    {
        // evrything to do when dead
        startedDying = true;
        enemyAnimator.enabled = true;
        enemyRigidbody.constraints = RigidbodyConstraints2D.FreezeRotation;
        Destroy(GetComponent<Collider2D>());
        if (projectileDirection != Vector2.zero)
        {
            directionToKnockback = ((Vector2)transform.position - projectileDirection).normalized;
        }
        else
        {
            directionToKnockback = (transform.position - player.transform.position).normalized;
        }
        enemyRigidbody.AddForce(directionToKnockback * 70);
        enemyAnimator.SetBool("IsDead", true);
        shadowAnimator.SetBool("Fade", true);
        enemyRigidbody.velocity = Vector2.zero;
        GetComponent<EnemyGeneral>().enabled = false;
        attackDamage = 0;
        Destroy(gameObject.transform.GetChild(0).gameObject.GetComponent<Collider2D>());

        // drop the upgrade
        /*        if (Random.Range(0f, 100f) < player.GetComponent<UpgradesList>().dropChance + player.GetComponent<UpgradesList>().badLuckProtection)
                {
                    upgradeDropped = Random.Range(0, player.GetComponent<UpgradesList>().Upgrade.Count);
                    gameObject.name = "UpgradeDropped";
                    Instantiate(UpgradeIcon, transform.position, UpgradeIcon.transform.rotation);
                    player.GetComponent<UpgradesList>().badLuckProtection = 0f;
                    player.GetComponent<UpgradesList>().dropChance -= player.GetComponent<UpgradesList>().dropChance / 10;
                }
                else
                {
                    player.GetComponent<UpgradesList>().badLuckProtection += player.GetComponent<UpgradesList>().dropChance / 200;
                }*/

        if (Random.Range(0f, 100f) < chanceToDropXP)
        {
            droppedXP_object = Instantiate(XPIcon, transform.position, XPIcon.transform.rotation);
            droppedXP_object.GetComponent<XpScript>().storedXP = droppedXP_amount + player.GetComponent<UpgradesList>().upgradeXP / 100 * droppedXP_amount;
        }

        yield return new WaitForEndOfFrame();

        yield return new WaitForSecondsRealtime(enemyAnimator.GetCurrentAnimatorStateInfo(0).length);

        // enemy Counter
        player.GetComponent<EnemyCounter>().enemyCounter++;

        player.GetComponent<EnemySpawner>().enemiesSpawned--;
        Destroy(gameObject);
    }

    /// <summary> 
    /// Function for stunning the mob when hit and playing the stun animation;
    /// </summary>
    /// <returns></returns>
    IEnumerator WaitBeforeMoving()
    {
        // function for stun
        stun = false;
        if (knockbackForce > 0)
        {
            gotPushed = true;
            //GetComponent<Animator>().SetBool("IsHurt", true);
            enemyAnimator.SetTrigger("IsHurt");
            if (projectileDirection != Vector2.zero)
            {
                directionToKnockback = ((Vector2)transform.position - projectileDirection).normalized;
            }
            else
            {
                directionToKnockback = (transform.position - player.transform.position).normalized;
            }
            enemyRigidbody.AddForce(directionToKnockback * knockbackForce);
            yield return new WaitForSecondsRealtime(0.1f);
            knockbackForce = 0;
            gotPushed = false;
        }
        else
        {
            enemyAnimator.SetTrigger("IsHurt");
        }
    }
    
    public void Freeze()
    {
        StartCoroutine(Frozen());
    }

    public IEnumerator Frozen()
    {
        frozen = true;
        enemyAnimator.SetTrigger("IsHurt");
        enemyRigidbody.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezePositionY | RigidbodyConstraints2D.FreezeRotation;
        yield return new WaitForEndOfFrame();
        enemyAnimator.enabled = false;
        yield return new WaitForSeconds(amountFrozen);
        enemyAnimator.enabled = true;
        enemyRigidbody.constraints = RigidbodyConstraints2D.FreezeRotation;
        frozen = false;
    }
}
