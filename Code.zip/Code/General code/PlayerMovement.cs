using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private float movingHorizontal;
    private float movingVertical;
    public Animator playerAnimator;
    public GameObject playerSprite;
    public float movementSpeed;
    public Rigidbody2D playerRigidbody;

    private bool dashing;
    private Vector2 directionToDash;
    private bool stillDashing = false;
    public float dashCooldown;
    private bool dashReady = true;
    // Start is called before the first frame update
    void Start()
    {
        Application.targetFrameRate = 144;
    }

    // Update is called once per frame
    void Update()
    {
        movingHorizontal = Input.GetAxisRaw("Horizontal");
        movingVertical = Input.GetAxisRaw("Vertical");

        if (dashReady)
        {
            dashing = Input.GetKeyDown(KeyCode.Space);
        }

        if (movingHorizontal != 0.0f || movingVertical != 0.0f)
        {
            if (dashing)
            {
                StartCoroutine(Dash());
                StartCoroutine(DashCooldown());
            }
        }
    }

    private void FixedUpdate()
    {
        if (!stillDashing)
        {
            if (movingHorizontal != 0.0f || movingVertical != 0.0f)
            { 
                playerRigidbody.velocity = new Vector3(movingHorizontal, movingVertical, 0.0f).normalized * movementSpeed;
                playerAnimator.SetBool("IsRunning", true);

                if (movingHorizontal > 0.0f)
                {
                    playerSprite.transform.rotation = Quaternion.Euler(0, 0, 0);
                }
                else
                {
                    if (movingHorizontal < 0.0f)
                    {
                        playerSprite.transform.rotation = Quaternion.Euler(0, 180, 0);
                    }
                }
            }
            else
            {
                playerRigidbody.velocity = Vector2.zero;
                playerAnimator.SetBool("IsRunning", false);
            }
        }
    }

    IEnumerator Dash()
    {
        dashing = false;
        stillDashing = true;
        directionToDash = new Vector2(movingHorizontal, movingVertical).normalized;
        playerRigidbody.AddForce(directionToDash * 700);
        yield return new WaitForSecondsRealtime(0.1f);
        stillDashing = false;
    }

    IEnumerator DashCooldown()
    {
        dashReady = false;
        yield return new WaitForSecondsRealtime(dashCooldown);
        dashReady = true;
    }
}
