using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BouncyDebuff : MonoBehaviour
{
    [HideInInspector] public float attackDamage;
    public GameObject drone;

    private void Start()
    {
        StartCoroutine(Destroy());
        InvokeRepeating("UpdateStats", 0, 3);
    }

    private void FixedUpdate()
    {
        transform.Rotate(0, 0, 200 * Time.deltaTime);
    }

    void UpdateStats()
    {
        drone.GetComponent<RotatingDroneAttaclEvemt>().attackDamage = attackDamage;
    }

    IEnumerator Destroy()
    {
        yield return new WaitForSeconds(5);
        Destroy(gameObject);
    }
}