using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShadowFollow : MonoBehaviour
{
    public GameObject meteor;
    public Vector3 destination;
    private void FixedUpdate()
    {
        if (meteor == null)
        {
            Destroy(gameObject);
        }
        else
        {
            if (!meteor.GetComponent<MeteorAttackEvent>().destroying)
            {
                    transform.position = new Vector3(meteor.transform.position.x, destination.y - 1.2f);
            }
            else
            {
                transform.position = new Vector3(meteor.transform.position.x, meteor.transform.position.y - 1.2f);
            }
        }
    }
}
