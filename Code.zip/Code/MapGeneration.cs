using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapGeneration : MonoBehaviour
{
    public GameObject[] tileMapToGenerate;

    private Vector2 cameraPosition;
    private int tile1;
    private int tile2;
    private int tile3;  


    private void FixedUpdate()
    {
        cameraPosition = new Vector2(Camera.main.transform.position.x, Camera.main.transform.position.y);

        if (Physics2D.OverlapBoxAll(new Vector2(cameraPosition.x + 30, cameraPosition.y), new Vector2(30.001f, 30.001f), 0, 1 << 14).Length == 0)
        {
            tile1 = Random.Range(0, tileMapToGenerate.Length);
            tile2 = Random.Range(0, tileMapToGenerate.Length);
            while (tile2 == tile1)
            {
                tile2 = Random.Range(0, tileMapToGenerate.Length);
            }
            tile3 = Random.Range(0, tileMapToGenerate.Length);
            while (tile3 == tile2 || tile3 == tile1)
            {
                tile3 = Random.Range(0, tileMapToGenerate.Length);
            }
            Instantiate(tileMapToGenerate[tile1], new Vector2(((int)cameraPosition.x / 30) * 30 + 45, (int)cameraPosition.y / 30 * 30 - 15), tileMapToGenerate[tile1].transform.rotation);
            Instantiate(tileMapToGenerate[tile2], new Vector2(((int)cameraPosition.x / 30) * 30 + 45, (int)cameraPosition.y / 30 * 30 + 15), tileMapToGenerate[tile2].transform.rotation);
            Instantiate(tileMapToGenerate[tile3], new Vector2(((int)cameraPosition.x / 30) * 30 + 45, (int)cameraPosition.y / 30 * 30 + 45), tileMapToGenerate[tile3].transform.rotation);
        }

        if (Physics2D.OverlapBoxAll(new Vector2(cameraPosition.x - 30, cameraPosition.y), new Vector2(30.001f, 30.001f), 0, 1 << 14).Length == 0)
        {
            tile1 = Random.Range(0, tileMapToGenerate.Length);
            tile2 = Random.Range(0, tileMapToGenerate.Length);
            while (tile2 == tile1)
            {
                tile2 = Random.Range(0, tileMapToGenerate.Length);
            }
            tile3 = Random.Range(0, tileMapToGenerate.Length);
            while (tile3 == tile2 || tile3 == tile1)
            {
                tile3 = Random.Range(0, tileMapToGenerate.Length);
            }
            Instantiate(tileMapToGenerate[tile1], new Vector2(((int)cameraPosition.x / 30) * 30 - 15, (int)cameraPosition.y / 30 * 30 - 15), tileMapToGenerate[tile1].transform.rotation);
            Instantiate(tileMapToGenerate[tile2], new Vector2(((int)cameraPosition.x / 30) * 30 - 15, (int)cameraPosition.y / 30 * 30 + 15), tileMapToGenerate[tile2].transform.rotation);
            Instantiate(tileMapToGenerate[tile3], new Vector2(((int)cameraPosition.x / 30) * 30 - 15, (int)cameraPosition.y / 30 * 30 + 45), tileMapToGenerate[tile3].transform.rotation);
        }

        if (Physics2D.OverlapBoxAll(new Vector2(cameraPosition.x, cameraPosition.y + 30), new Vector2(30.001f, 30.001f), 0, 1 << 14).Length == 0)
        {
            tile1 = Random.Range(0, tileMapToGenerate.Length);
            tile2 = Random.Range(0, tileMapToGenerate.Length);
            while (tile2 == tile1)
            {
                tile2 = Random.Range(0, tileMapToGenerate.Length);
            }
            tile3 = Random.Range(0, tileMapToGenerate.Length);
            while (tile3 == tile2 || tile3 == tile1)
            {
                tile3 = Random.Range(0, tileMapToGenerate.Length);
            }
            Instantiate(tileMapToGenerate[tile1], new Vector2((int)cameraPosition.x / 30 * 30 + 45, (int)cameraPosition.y / 30 * 30 + 45), tileMapToGenerate[tile1].transform.rotation);
            Instantiate(tileMapToGenerate[tile2], new Vector2((int)cameraPosition.x / 30 * 30 - 15, (int)cameraPosition.y / 30 * 30 + 45), tileMapToGenerate[tile2].transform.rotation);
            Instantiate(tileMapToGenerate[tile3], new Vector2((int)cameraPosition.x / 30 * 30 + 15, (int)cameraPosition.y / 30 * 30 + 45), tileMapToGenerate[tile3].transform.rotation);
        }

        if (Physics2D.OverlapBoxAll(new Vector2(cameraPosition.x, cameraPosition.y - 30), new Vector2(30.001f, 30.001f), 0, 1 << 14).Length == 0)
        {
            tile1 = Random.Range(0, tileMapToGenerate.Length);
            tile2 = Random.Range(0, tileMapToGenerate.Length);
            while (tile2 == tile1)
            {
                tile2 = Random.Range(0, tileMapToGenerate.Length);
            }
            tile3 = Random.Range(0, tileMapToGenerate.Length);
            while (tile3 == tile2 || tile3 == tile1)
            {
                tile3 = Random.Range(0, tileMapToGenerate.Length);
            }
            Instantiate(tileMapToGenerate[tile1], new Vector2((int)cameraPosition.x / 30 * 30 + 45, (int)cameraPosition.y / 30 * 30 - 15), tileMapToGenerate[tile1].transform.rotation);
            Instantiate(tileMapToGenerate[tile2], new Vector2((int)cameraPosition.x / 30 * 30 - 15, (int)cameraPosition.y / 30 * 30 - 15), tileMapToGenerate[tile2].transform.rotation);
            Instantiate(tileMapToGenerate[tile3], new Vector2((int)cameraPosition.x / 30 * 30 + 15, (int)cameraPosition.y / 30 * 30 - 15), tileMapToGenerate[tile3].transform.rotation);
        }
    }
}
