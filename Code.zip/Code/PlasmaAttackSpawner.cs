using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlasmaAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public int maxEnemiesHit;
    public bool augmented;
    public float amountFrozen;

    private bool doneAttacking = false;
    public GameObject gameManager;

    private GameObject closestEnemy;

    private void FixedUpdate()
    {
        if (!doneAttacking)
        {
            StartCoroutine(LaunchProjectile());
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;
        gameManager.GetComponent<FindClosestEnemy>().FindEnemy();

        for (int i = 1; i <= 1 + gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            int enemyIndex = Random.Range(0, gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length);
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies[enemyIndex] != null)
            {
                closestEnemy = gameManager.GetComponent<FindClosestEnemy>().allEnemies[enemyIndex].gameObject;
                Vector2 direction = closestEnemy.transform.position - transform.position;
                float angle = Mathf.Atan2(direction.y + 0.5f, direction.x) * Mathf.Rad2Deg;
                Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
                transform.rotation = rotation;

                GameObject instance = Instantiate(projectile, transform.position, transform.rotation);
                instance.GetComponent<PlasmaAttackEvent>().attackDamage = attackDamage;
                instance.GetComponent<PlasmaAttackEvent>().closestEnemy = closestEnemy;
                instance.GetComponent<PlasmaAttackEvent>().projectileSpeed = projectileSpeed;
                instance.GetComponent<PlasmaAttackEvent>().maxEnemiesHit = maxEnemiesHit;
                instance.GetComponent<PlasmaAttackEvent>().augmented = augmented;
                instance.GetComponent<PlasmaAttackEvent>().amountFrozen = amountFrozen;
                instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
                yield return new WaitForSeconds(0.65f);
            }
        }

        yield return new WaitForSeconds(attackSpeed);
        doneAttacking = false;
    }
}

