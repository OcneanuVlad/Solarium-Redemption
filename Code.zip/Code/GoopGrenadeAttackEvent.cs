using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoopGrenadeAttackEvent : MonoBehaviour
{
    [HideInInspector] public Vector3 point2;
    private Vector3 positionInCamera;
    private Vector3 point0;
    private Vector3 point1;
    private float count = 0.0f;

    public GameObject gameManager;
    public GameObject puddle;
    [HideInInspector] public float attackDamage;
    [HideInInspector] public bool augmented;
    [HideInInspector] public float duration;

    private void Start()
    {
        point0 = transform.position;
        point1 = point0 + (point2 - point0) / 2 + Vector3.up * 5.0f;
    }
    void Update()
    {
        positionInCamera = Camera.main.WorldToViewportPoint(transform.position);
        if (positionInCamera.x < -0.2f || positionInCamera.x > 1.2f || positionInCamera.y < -0.2 || positionInCamera.y > 1.2)
        {
            Destroy(gameObject);
        }

        if (count < 1.0f)
        {
            count += 1.0f * Time.deltaTime;

            Vector3 m1 = Vector3.Lerp(point0, point1, count);
            Vector3 m2 = Vector3.Lerp(point1, point2, count);
            transform.position = Vector3.Lerp(m1, m2, count);
        }
        else
        {
            GameObject instance = Instantiate(puddle, transform.position, puddle.transform.rotation);
            instance.GetComponent<GoopPuddleAttackEvent>().attackDamage = attackDamage;
            instance.GetComponent<GoopPuddleAttackEvent>().duration = duration;
            instance.GetComponent<GoopPuddleAttackEvent>().augmented = augmented;
            instance.transform.localScale = transform.localScale * 1.7f;
            instance.transform.localScale += gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale;
            Destroy(gameObject);
        }
    }
}
