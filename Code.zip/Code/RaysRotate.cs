using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RaysRotate : MonoBehaviour
{
    void FixedUpdate()
    {
        transform.Rotate(0, 0, 10 * Time.deltaTime);
    }
}
