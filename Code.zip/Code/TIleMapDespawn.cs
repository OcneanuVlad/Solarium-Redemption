using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TIleMapDespawn : MonoBehaviour
{
    private void FixedUpdate()
    {
        if (Mathf.Abs(transform.position.x - Camera.main.transform.position.x) > 45)
        {
            Destroy(gameObject);
        }

        if (Mathf.Abs(transform.position.y - Camera.main.transform.position.y) > 45)
        {
            Destroy(gameObject);
        }
    }
}
