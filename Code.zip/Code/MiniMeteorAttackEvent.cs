using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MiniMeteorAttackEvent : MonoBehaviour
{
    [HideInInspector] public Vector3 point2;
    [HideInInspector] public Vector3 randomPoint;
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;
    [HideInInspector] public bool augmented;
    public GameObject miniMeteor;
    private Vector3 point0;
    private Vector3 point1;
    private bool destroying;

    public GameObject explosion;

    private float count = 0f;

    void Start()
    {
        point0 = transform.position;
        if (augmented)
        {
            point1 = point0 + (point2 - point0) / 2 + Vector3.up * 2.5f;
        }
        else
        {
            point1 = point0 + (point2 - point0) / 2 + Vector3.up * 1.7f;
        }
    }

    void Update()
    {
        if (count < 1.0f)
        {
            count += 1.0f * Time.deltaTime;

            Vector3 m1 = Vector3.Lerp(point0, point1, count);
            Vector3 m2 = Vector3.Lerp(point1, point2, count);
            Vector3 lerp = Vector3.Lerp(m1, m2, count);

            Vector2 direction = lerp - transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            transform.rotation = rotation;

            transform.position = lerp;
        }
        else
        {
            if (!destroying)
            {
                WaitBeforeDestroy();
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage;
            collision.gameObject.GetComponent<EnemyGeneral>().projectileDirection = transform.position;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            {
                collision.gameObject.GetComponent<EnemyGeneral>().knockbackForce = knockbackForce;
                collision.gameObject.GetComponent<EnemyGeneral>().stun = true;
            }
        }
    }

    void WaitBeforeDestroy()
    {
        destroying = true;
        GameObject instance = Instantiate(explosion, transform.position, transform.rotation);
        instance.GetComponent<DespawnExplosion>().attackDamage = attackDamage;
        instance.transform.localScale = new Vector3(transform.localScale.x * 4, transform.localScale.x * 4);
        if (augmented && Random.Range(0f, 100f) < 35f)
        {
            SpawnMiniMeteor();
        }
        Destroy(gameObject);
    }

    void SpawnMiniMeteor()
    {
        GameObject instance = Instantiate(miniMeteor, new Vector2(transform.position.x, transform.position.y - 0.5f), transform.rotation);
        instance.GetComponent<MiniMeteorAttackEvent>().attackDamage = attackDamage;
        instance.GetComponent<MiniMeteorAttackEvent>().knockbackForce = knockbackForce / 2;
        instance.GetComponent<MiniMeteorAttackEvent>().point2 = randomPoint / 1.5f + transform.position;
        instance.GetComponent<MiniMeteorAttackEvent>().augmented = false;
        instance.transform.localScale = instance.transform.localScale / 1.5f;
    }
}
