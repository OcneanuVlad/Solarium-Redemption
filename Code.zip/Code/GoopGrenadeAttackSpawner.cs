using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoopGrenadeAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float attackDamage;
    public float duration;
    public float projectileSpeed = 0;
    public float knockbackForce = 0;
    public bool augmented;
    public float scale = 2.4f;

    private bool doneAttacking = false;
    public GameObject gameManager;
    private GameObject enemyToDamage;


    private void FixedUpdate()
    {
        if (!doneAttacking)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
            {
                StartCoroutine(LaunchProjectile());
            }
            else
            {
                gameManager.GetComponent<FindClosestEnemy>().FindEnemy();
            }
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;
        gameManager.GetComponent<FindClosestEnemy>().FindEnemy();

        for (int i = 1; i <= 1 + gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
            {
                int randomEnemy = Random.Range(0, gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length);
                if (gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy] != null)
                {
                    enemyToDamage = gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy].gameObject;

                    GameObject instance = Instantiate(projectile, transform.position, transform.rotation);
                    instance.GetComponent<GoopGrenadeAttackEvent>().attackDamage = attackDamage;
                    instance.GetComponent<GoopGrenadeAttackEvent>().point2 = enemyToDamage.transform.position;
                    instance.GetComponent<GoopGrenadeAttackEvent>().duration = duration;
                    instance.GetComponent<GoopGrenadeAttackEvent>().augmented = augmented;
                    instance.transform.localScale = new Vector3(scale, scale);
                    instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
                    yield return new WaitForSeconds(0.45f);
                }
            }
        }

        yield return new WaitForSeconds(attackSpeed);
        doneAttacking = false;
    }
}

