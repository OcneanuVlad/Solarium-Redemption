using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;


public class DLC : MonoBehaviour
{
    public Text text4;
    public Text text2;
    public Text text3;

    public GameObject button;

    public GameObject dlcBox;

    public void Text4MouseOverEnter()
    {
        text4.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text4MouseOverExit()
    {
        text4.color = new Color(1, 1, 1);
    }

    public void Text2MouseOverEnter()
    {
        text2.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text2MouseOverExit()
    {
        text2.color = new Color(1, 1, 1);
    }

    public void Text3MouseOverEnter()
    {
        text3.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text3MouseOverExit()
    {
        text3.color = new Color(1, 1, 1);
    }

    public void DLCOpen()
    {
        dlcBox.SetActive(true);
    }

    public void DLCClose()
    {
        dlcBox.SetActive(false);
    }

    public void DLCinstall()
    {
        button.SetActive(false);
        var assetBundle = AssetBundle.LoadFromFile(Path.Combine(Application.streamingAssetsPath, "dlc"));
        assetBundle.LoadAllAssets();
    }
}
