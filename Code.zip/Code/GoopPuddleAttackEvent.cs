using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoopPuddleAttackEvent : MonoBehaviour
{
    private List<GameObject> enemiesInPuddle;
    [HideInInspector] public float attackDamage;
    private bool givingDamage;
    [HideInInspector] public float duration;
    [HideInInspector] public bool augmented;

    private float scaleX;
    private float scaleY;

    public GameObject gameManager;

    private void Start()
    {
        scaleX = transform.localScale.x;
        scaleY = transform.localScale.y;
        enemiesInPuddle = new List<GameObject>();
    }

    private void FixedUpdate()
    {
        if (enemiesInPuddle.Count > 0)
        {
            if (!givingDamage)
            {
                for (int i = 0; i < enemiesInPuddle.Count; i++)
                {
                    StartCoroutine(DamageEnemies(enemiesInPuddle[i]));
                }
            }
        }

        duration -= Time.deltaTime;

        if (duration <= 0)
        {
            StartCoroutine(Despawn());
        }

        if (scaleX > transform.localScale.x)
        {
            transform.localScale += new Vector3(scaleX - transform.localScale.x, scaleY - transform.localScale.y) * Time.deltaTime;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        enemiesInPuddle.Add(collision.gameObject);
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        enemiesInPuddle.Remove(collision.gameObject);
    }

    IEnumerator DamageEnemies(GameObject enemy)
    {
        givingDamage = true;
        enemy.gameObject.GetComponentInParent<EnemyGeneral>().currentEnemyHealth -= attackDamage + gameManager.GetComponent<AttackStats>().attackDamage * attackDamage;
        if (enemy.gameObject.GetComponentInParent<EnemyGeneral>().currentEnemyHealth <= 0)
        {
            enemy.gameObject.GetComponentInParent<EnemyGeneral>().die = true;
            if (augmented)
            {
                scaleX += 0.25f * 4f;
                scaleY += 0.25f * 1.5f;
            }
        }
        else
        {
            enemy.gameObject.GetComponentInParent<EnemyGeneral>().stun = true;
        }
        yield return new WaitForSecondsRealtime(0.3f);
        givingDamage = false;
    }

    IEnumerator Despawn()
    {
        GetComponent<Animator>().SetBool("Despawn", true);
        GetComponent<Collider2D>().enabled = false;
        yield return new WaitForEndOfFrame();
        yield return new WaitForSeconds(GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).length);
        Destroy(gameObject);
    }
}
