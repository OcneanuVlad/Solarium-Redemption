using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LoadingScreen : MonoBehaviour
{
    [SerializeField] private GameObject loadingScreen;
    [HideInInspector] public bool loading = true;

    private void Start()
    {
        loadingScreen.SetActive(true);
        loading = true;
        Time.timeScale = 0;
        StartCoroutine(Loading());
    }

    IEnumerator Loading()
    {
        yield return new WaitForSecondsRealtime(3);
        loadingScreen.SetActive(false);
        loading = false;
        GetComponent<UpgradeBoxPopUp>().StartBox();
    }
}
