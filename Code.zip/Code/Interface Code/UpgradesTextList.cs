using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpgradesTextList : MonoBehaviour
{
    private new int name = 0;
    private int description = 1;

    public GameObject player;

    public List<string> AugmentText;
    public List<string[]> UpgradeText;
    public List<Sprite> icons;
    public List<Sprite> augmentIcons;

    //augment icons
    public Sprite iconAugment0;
    public Sprite iconAugment1;
    public Sprite iconAugment2;
    public Sprite iconAugment3;
    public Sprite iconAugment4;
    public Sprite iconAugment5;
    public Sprite iconAugment6;
    public Sprite iconAugment7;
    public Sprite iconAugment8;
    public Sprite iconAugment9;
    public Sprite iconAugment10;
    public Sprite iconAugment11;
    public Sprite iconAugment12;
    public Sprite iconAugment13;

    // icons
    public Sprite icon0;
    public Sprite icon1;
    public Sprite icon2;
    public Sprite icon3;
    public Sprite icon4;
    public Sprite icon5;
    public Sprite icon6;
    public Sprite icon7;
    public Sprite icon8;
    public Sprite icon9;
    public Sprite icon10;
    public Sprite icon11;
    public Sprite icon12;
    public Sprite icon13;
    public Sprite icon14;
    public Sprite icon15;
    public Sprite icon16;
    public Sprite icon17;
    public Sprite icon18;
    public Sprite icon19;
    public Sprite icon20;
    public Sprite icon21;
    public Sprite icon22;
    public Sprite icon23;
    public Sprite icon24;


    // augment text
    [HideInInspector] public string augment0;
    [HideInInspector] public string augment1;
    [HideInInspector] public string augment2;
    [HideInInspector] public string augment3;
    [HideInInspector] public string augment4;
    [HideInInspector] public string augment5;
    [HideInInspector] public string augment6;
    [HideInInspector] public string augment7;
    [HideInInspector] public string augment8;
    [HideInInspector] public string augment9;
    [HideInInspector] public string augment10;
    [HideInInspector] public string augment11;
    [HideInInspector] public string augment12;
    [HideInInspector] public string augment13;
    [HideInInspector] public string augment14;
    [HideInInspector] public string augment15;

    // text declaration
    [HideInInspector] public string[] text0;
    [HideInInspector] public string[] text1;
    [HideInInspector] public string[] text2;
    [HideInInspector] public string[] text3;
    [HideInInspector] public string[] text4;
    [HideInInspector] public string[] text5;
    [HideInInspector] public string[] text6;
    [HideInInspector] public string[] text7;
    [HideInInspector] public string[] text8;
    [HideInInspector] public string[] text9;
    [HideInInspector] public string[] text10;
    [HideInInspector] public string[] text11;
    [HideInInspector] public string[] text12;
    [HideInInspector] public string[] text13;
    [HideInInspector] public string[] text14;
    [HideInInspector] public string[] text15;
    [HideInInspector] public string[] text16;
    [HideInInspector] public string[] text17;
    [HideInInspector] public string[] text18;
    [HideInInspector] public string[] text19;
    [HideInInspector] public string[] text20;
    [HideInInspector] public string[] text21;
    [HideInInspector] public string[] text22;
    [HideInInspector] public string[] text23;
    [HideInInspector] public string[] text24;
    [HideInInspector] public string[] text25;
    [HideInInspector] public string[] text26;
    [HideInInspector] public string[] text27;

    [HideInInspector] public string[] fillerText1;
    [HideInInspector] public string[] fillerText2;
    [HideInInspector] public string[] fillerText3;

    void Start()
    {
        CreateText();

        CreateList();
    }

    void CreateList()
    {
        AugmentText = new List<string>();

        //AugmentText.Add(augment0);
        AugmentText.Add(augment1);
        AugmentText.Add(augment2);
        AugmentText.Add(augment3);
        AugmentText.Add(augment4);
        AugmentText.Add(augment5);
        AugmentText.Add(augment6);
        AugmentText.Add(augment7);
        AugmentText.Add(augment8);
        AugmentText.Add(augment9);
        AugmentText.Add(augment10);
        AugmentText.Add(augment11);
        //AugmentText.Add(augment12);
        //AugmentText.Add(augment13);
        /*AugmentText.Add(augment14);
        AugmentText.Add(augment15);*/

        UpgradeText = new List<string[]>();

        UpgradeText.Add(text0);
        UpgradeText.Add(text1);
        UpgradeText.Add(text2);
        //UpgradeText.Add(text3);
        UpgradeText.Add(text4);
        UpgradeText.Add(text5);
        UpgradeText.Add(text6);
        UpgradeText.Add(text7);
        UpgradeText.Add(text8);
        UpgradeText.Add(text9);
        UpgradeText.Add(text10);
        UpgradeText.Add(text11);
        UpgradeText.Add(text12);
        UpgradeText.Add(text13);
        UpgradeText.Add(text14);
        //UpgradeText.Add(text15);
        /*UpgradeText.Add(text16);
        UpgradeText.Add(text17);
        UpgradeText.Add(text18);*/
        UpgradeText.Add(text19);
        UpgradeText.Add(text20);
        UpgradeText.Add(text21);
        //UpgradeText.Add(text22);
        UpgradeText.Add(text23);
        UpgradeText.Add(text24);
        UpgradeText.Add(text25);
        UpgradeText.Add(text26);
        UpgradeText.Add(text27);

        augmentIcons = new List<Sprite>();
        augmentIcons.Add(iconAugment0);
        augmentIcons.Add(iconAugment1);
        augmentIcons.Add(iconAugment2);
        augmentIcons.Add(iconAugment3);
        augmentIcons.Add(iconAugment4);
        augmentIcons.Add(iconAugment5);
        augmentIcons.Add(iconAugment6);
        augmentIcons.Add(iconAugment7);
        augmentIcons.Add(iconAugment8);
        augmentIcons.Add(iconAugment9);
        augmentIcons.Add(iconAugment10);
        /*augmentIcons.Add(iconAugment11);
        augmentIcons.Add(iconAugment12);
        augmentIcons.Add(iconAugment13);*/

        icons = new List<Sprite>();
        icons.Add(icon0);
        icons.Add(icon1);
        icons.Add(icon2);
        icons.Add(icon3);
        icons.Add(icon4);
        icons.Add(icon5);
        icons.Add(icon6);
        icons.Add(icon7);
        icons.Add(icon8);
        icons.Add(icon9);
        icons.Add(icon10);
        icons.Add(icon11);
        icons.Add(icon12);
        icons.Add(icon13);
        /*icons.Add(icon14);
        icons.Add(icon15);
        icons.Add(icon16);*/
        icons.Add(icon17);
        icons.Add(icon18);
        icons.Add(icon19);
        icons.Add(icon20);
        icons.Add(icon21);
        icons.Add(icon22);
        icons.Add(icon23);
        icons.Add(icon24);
    }

    public void CreateText()
    {
        text0 = new string[2];
        text0[name] = "Double projectiles";
        text0[description] = "All weapons attack one more time";

        text1 = new string[2];
        text1[name] = "Max Health";
        text1[description] = "Increases maximum HP by 20%";

        text2 = new string[2];
        text2[name] = "Movement speed";
        text2[description] = "Increases movement speed by 10%";

        text3 = new string[2];
        text3[name] = "Piercing Spikes";
        text3[description] = "Shoots 3 spikes in a row. They can pierce enemies";

        text4 = new string[2];
        text4[name] = "Lightning aparatus";
        text4[description] = "Lightning strikes 3 random enemies";

        text5 = new string[2];
        text5[name] = "Rocket launcher";
        text5[description] = "Shoots a homing rocket at a random enemy. The rocket deals AOE damage";

        text6 = new string[2];
        text6[name] = "Energy sword";
        text6[description] = "Swings an energy sword around you";

        text7 = new string[2];
        text7[name] = "Proximity drones";
        text7[description] = "Get 2 drones that fly around you continuously";

        text8 = new string[2];
        text8[name] = "X lasers";
        text8[description] = "Shoots lasers in an X shape";

        text9 = new string[2];
        text9[name] = "Goop grenade";
        text9[description] = "Throw a grenade that leaves a puddle of goop on the ground";

        text10 = new string[2];
        text10[name] = "Light scythe";
        text10[description] = "Launches a light scythe that travels in circles";

        text11 = new string[2];
        text11[name] = "Meteor magnet";
        text11[description] = "Meteors fall from the sky at random positions";

        text12 = new string[2];
        text12[name] = "Photon knives";
        text12[description] = "Shoots 3 photon knives in a cone";

        text13 = new string[2];
        text13[name] = "Plasma";
        text13[description] = "Shoots a Plasma Ball that stuns enemies that it passes trough";

        text14 = new string[2];
        text14[name] = "Unstable energy";
        text14[description] = "Shoots a ball of unstable energy that passes trough enemies getting smaller";

        text15 = new string[2];
        text15[name] = "Bouncy";
        text15[description] = "Shoots a projectile that bounces projectile";

        text16 = new string[2];
        text16[name] = "Ray";
        text16[description] = "Shoots a beam of energy aiming at the cursor";

        text17 = new string[2];
        text17[name] = "Minigun";
        text17[description] = "Spin the minigun shooting lots of bullets";

        text18 = new string[2];
        text18[name] = "Homing Rockets";
        text18[description] = "Shoots aimed Rockets at the crosshair";

        text19 = new string[2];
        text19[name] = "Cooldown";
        text19[description] = "Decreases cooldown for all attacks by 10%";

        text20 = new string[2];
        text20[name] = "Projectile Speed";
        text20[description] = "Increases projectile speed for all attacks by 15%";

        text21 = new string[2];
        text21[name] = "Attack Damage";
        text21[description] = "Increases attack damage for all attacks by 10%";

        text22 = new string[2];
        text22[name] = "Knockback";
        text22[description] = "Increases knockback for all attack by 7%";

        text23 = new string[2];
        text23[name] = "Projectile Size";
        text23[description] = "Increases projectile size for all attacks by 10%";

        text24 = new string[2];
        text24[name] = "XP increase";
        text24[description] = "Increases xp gained by 10%";

        text25 = new string[2];
        text25[name] = "Pickup Range";
        text25[description] = "Increases the pickup range by 100%";

        text26 = new string[2];
        text26[name] = "Damage Reduction";
        text26[description] = "The damage received is reduced by 10%";

        text27 = new string[2];
        text27[name] = "Health regeneration";
        text27[description] = "Regenerate +0.5% health per second";





        // augment
        augment0 = "Piercing Spikes";
        augment1 = "Lightning";
        augment2 = "Rockets";
        augment3 = "Sword";
        augment4 = "Drones";
        augment5 = "X Lasers";
        augment6 = "Grenade";
        augment7 = "Scythe";
        augment8 = "Meteors";
        augment9 = "Knives";
        augment10 = "Plasma";
        augment11 = "Energy";
        augment12 = "Bouncy";
        augment13 = "Solar Ray";
        augment14 = "Minigun";
        augment15 = "Homing Rockets";

        // filler
        fillerText1 = new string[2];
        fillerText1[name] = "Heal";
        fillerText1[description] = "Restores 30% HP";

        fillerText2 = new string[2];
        fillerText2[name] = "Sun pieces";
        fillerText2[description] = "Get 10 sun pieces";

        fillerText3 = new string[2];
        fillerText3[name] = "Teleport";
        fillerText3[description] = "Teleport to the nearest dome market";
    }

}
