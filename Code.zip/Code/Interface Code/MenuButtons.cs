using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuButtons : MonoBehaviour
{
    public Text text1;
    public Text text2;
    public Text text3;
    public Text text4;

    public Animator buttonsAnimator;
    public Animator loadingAnimator;

    public void Load()
    {
        StartCoroutine(LoadGame());
    }

    public IEnumerator LoadGame()
    {
        buttonsAnimator.SetTrigger("FadeOut");
        yield return new WaitForEndOfFrame();
        yield return new WaitForSeconds(buttonsAnimator.GetCurrentAnimatorStateInfo(0).length);
        Camera.main.gameObject.GetComponent<Animator>().SetBool("Transition", true);
        yield return new WaitForEndOfFrame();
        yield return new WaitForSeconds(Camera.main.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).length);
        //loadingAnimator.SetTrigger("FadeIn");

        SceneManager.LoadScene("Map1");

        /*AsyncOperation asyncLoad = SceneManager.LoadSceneAsync("Map1");

        while (!asyncLoad.isDone)
        {
            yield return null;
        }*/

        //SceneManager.LoadScene("Map1");
    }

    public void Quit()
    {
        Application.Quit();
    }





    public void Text1MouseOverEnter()
    {
        text1.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text1MouseOverExit()
    {
        text1.color = new Color(0, 0, 0.08f);
    }

    public void Text2MouseOverEnter()
    {
        text2.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text2MouseOverExit()
    {
        text2.color = new Color(0, 0, 0.08f);
    }

    public void Text3MouseOverEnter()
    {
        text3.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text3MouseOverExit()
    {
        text3.color = new Color(0, 0, 0.08f);
    }

    public void Text4MouseOverEnter()
    {
        text4.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text4MouseOverExit()
    {
        text4.color = new Color(0, 0, 0.08f);
    }
}
