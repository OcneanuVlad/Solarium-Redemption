using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class XPBarScript : MonoBehaviour
{
    [HideInInspector] public float currentXP = 0;
    public float maxXP;
    public Image XPbar;
    public GameObject gameManager;

    public Animator upgradeBoxAnimator;

    public Text playerLevel;
    private int level = 1;

    void Start()
    {
        playerLevel.text = "LVL. " + level.ToString();

    }

    void Update()
    {
        if (currentXP / maxXP != XPbar.fillAmount)
        {
            XPbar.fillAmount += (currentXP / maxXP - XPbar.fillAmount) * (Time.deltaTime * 2f);
        }

        if (XPbar.fillAmount == 1 && currentXP >= maxXP)
        {
            if (!gameManager.GetComponent<UpgradeBoxPopUp>().isOpen)
            {
                currentXP -= maxXP;
                maxXP += (15f / 100f) * maxXP;
                level++;
                playerLevel.text = "LVL. " + level.ToString();
                Time.timeScale = 0;
                gameManager.GetComponent<UpgradeBoxPopUp>().UpgradeBoxOpen();
            }
        }
    }
}
