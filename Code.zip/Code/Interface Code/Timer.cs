using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    private float secondsSurvived = 0;
    [HideInInspector] public int minutesSurvived = 0;
    private int hoursSurvived = 0;
    public Text timer;

    private void FixedUpdate()
    {
        secondsSurvived += Time.deltaTime;
        if (secondsSurvived >= 60)
        {
            minutesSurvived++;
            secondsSurvived = 0;
            if (minutesSurvived >= 60)
            {
                hoursSurvived++;
            }
        }

        timer.text = string.Format("{0:00}:{1:00}:{2:00}", hoursSurvived, minutesSurvived, Mathf.FloorToInt(secondsSurvived));
    }
}
