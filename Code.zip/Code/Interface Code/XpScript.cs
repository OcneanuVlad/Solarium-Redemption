using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class XpScript : MonoBehaviour
{
    [HideInInspector] public float storedXP;
    private GameObject player;
    public GameObject pivot;
    private Vector3 pivotPosition;

    private bool movePivot;
    private bool movePlayer;
    private bool getXP;
    private bool collected;


    private void FixedUpdate()
    {
        if (movePivot)
        {
            transform.position = Vector3.Lerp(transform.position, pivotPosition, 0.05f);
        }
        else
        {
            if (movePlayer)
            {
                transform.position = Vector3.Lerp(transform.position, new Vector3(player.transform.position.x, player.transform.position.y + 0.55f, 0), 0.1f);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("PickupCollider") && !collected)
        {
            Vector2 direction = collision.gameObject.transform.position - transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            transform.rotation = rotation;
            pivotPosition = pivot.transform.position;

            transform.GetChild(1).gameObject.SetActive(false);

            StartCoroutine(Pickup());
            player = collision.gameObject;
            collected = true;
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && getXP)
        {
            collision.gameObject.GetComponent<XPBarScript>().currentXP += storedXP;
            Destroy(gameObject);
        }
    }

    IEnumerator Pickup()
    {
        movePivot = true;
        yield return new WaitForSeconds(0.5f);
        movePivot = false;
        movePlayer = true;
        getXP = true;
    }
}
