using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class UpgradeBoxPopUp : MonoBehaviour
{
    public GameObject UpgradeBox;
    private Animator UpgradeBoxAnimator;
    public GameObject player;

    private new int name = 0;
    private int description = 1;

    private int upgrade1;
    private int upgrade2;
    private int upgrade3;

    private int augment;
    private int augmentLucky;
    private bool lucky;

    public Text errorText;

    public TextMeshProUGUI upgrade_1_name;
    public TextMeshProUGUI upgrade_2_name;
    public TextMeshProUGUI upgrade_3_name;
    public TextMeshProUGUI upgrade_1_description;
    public TextMeshProUGUI upgrade_2_description;
    public TextMeshProUGUI upgrade_3_description;

    public TextMeshProUGUI augment_name;
    public TextMeshProUGUI augment_description;

    public GameObject button1;
    public GameObject button2;
    public GameObject button3;
    public GameObject buttonAugment;
    public GameObject button1filler;
    public GameObject button2filler;
    public GameObject button3filler;
    public GameObject buttonAugmentFiller;

    public GameObject Upgrade1Box;
    public GameObject Upgrade2Box;
    public GameObject Upgrade3Box;

    public Image icon1;
    public Image icon2;
    public Image icon3;
    public Image icon4;

    [HideInInspector] public bool isOpen;

    private void Start()
    {
        UpgradeBoxAnimator = UpgradeBox.GetComponent<Animator>();

        player = GameObject.Find("Player");
        UpgradeBox.GetComponent<Animator>().updateMode = AnimatorUpdateMode.UnscaledTime;
        errorText.GetComponent<Animator>().updateMode = AnimatorUpdateMode.UnscaledTime;
    }

    public void UpgradeBoxOpen()
    {
        isOpen = true;
        Time.timeScale = 0;
        GetComponent<Interface>().isInUpgradeBox = true;

        if (player.GetComponent<UpgradesList>().weaponsAugmented < 6)
        {
            if (player.GetComponent<UpgradesList>().availableAugments.Count > 0 && Random.Range(0f, 100f) > 50f)
            {
                augmentLucky = Random.Range(0, player.GetComponent<UpgradesList>().availableAugments.Count);
                augment = player.GetComponent<UpgradesList>().availableAugments[augmentLucky];
                lucky = true;
            }
            else
            {
                augment = Random.Range(0, player.GetComponent<UpgradesList>().Augment.Count);
                lucky = false;
            }
            icon4.sprite = GetComponent<UpgradesTextList>().augmentIcons[augment];
            Debug.Log("1");
            augment_name.text = GetComponent<UpgradesTextList>().AugmentText[augment] + " Chip";
            Debug.Log("2");
            augment_description.text = "Augment chip for the " + GetComponent<UpgradesTextList>().AugmentText[augment];
            Debug.Log("3");
        }
        else
        {
            augment_name.text = "Pouch of Sun Pieces";
            augment_description.text = "Get 200 sun pieces";
            buttonAugment.SetActive(false);
            buttonAugmentFiller.SetActive(true);
        }

        switch (GetComponent<UpgradesTextList>().UpgradeText.Count)
        {
            case 0:
                Upgrade2Box.SetActive(true);
                Upgrade3Box.SetActive(true);
                Upgrade1Box.transform.localPosition = new Vector3(-270, Upgrade1Box.transform.localPosition.y);
                Upgrade2Box.transform.localPosition = new Vector3(0, Upgrade2Box.transform.localPosition.y);
                Upgrade3Box.transform.localPosition = new Vector3(270, Upgrade3Box.transform.localPosition.y);

                button1.SetActive(false);
                button2.SetActive(false);
                button3.SetActive(false);
                button1filler.SetActive(true);
                button2filler.SetActive(true);
                button3filler.SetActive(true);

                upgrade_1_name.text = GetComponent<UpgradesTextList>().fillerText1[name];
                upgrade_2_name.text = GetComponent<UpgradesTextList>().fillerText2[name];
                upgrade_3_name.text = GetComponent<UpgradesTextList>().fillerText3[name];
                upgrade_1_description.text = GetComponent<UpgradesTextList>().fillerText1[description];
                upgrade_2_description.text = GetComponent<UpgradesTextList>().fillerText2[description];
                upgrade_3_description.text = GetComponent<UpgradesTextList>().fillerText3[description];


                UpgradeBox.GetComponent<Animator>().ResetTrigger("Close");
                UpgradeBox.GetComponent<Animator>().SetTrigger("PopUp");
                break;
            case 1:
                upgrade1 = Random.Range(0, GetComponent<UpgradesTextList>().UpgradeText.Count);

                Upgrade2Box.SetActive(false);
                Upgrade1Box.transform.localPosition = new Vector3(0, Upgrade1Box.transform.localPosition.y);

                icon1.sprite = GetComponent<UpgradesTextList>().icons[upgrade1];

                upgrade_1_name.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade1][name];
                upgrade_1_description.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade1][description];

                UpgradeBox.GetComponent<Animator>().ResetTrigger("Close");
                UpgradeBox.GetComponent<Animator>().SetTrigger("PopUp");
                break;
            case 2:
                upgrade1 = Random.Range(0, GetComponent<UpgradesTextList>().UpgradeText.Count);
                upgrade2 = Random.Range(0, GetComponent<UpgradesTextList>().UpgradeText.Count);
                while (upgrade2 == upgrade1)
                {
                    upgrade2 = Random.Range(0, GetComponent<UpgradesTextList>().UpgradeText.Count);
                }

                Upgrade3Box.SetActive(false);
                Upgrade2Box.transform.localPosition = new Vector3(195, Upgrade2Box.transform.localPosition.y);
                Upgrade1Box.transform.localPosition = new Vector3(-195, Upgrade1Box.transform.localPosition.y);

                icon1.sprite = GetComponent<UpgradesTextList>().icons[upgrade1];
                icon2.sprite = GetComponent<UpgradesTextList>().icons[upgrade2];

                upgrade_1_name.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade1][name];
                upgrade_2_name.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade2][name];
                upgrade_1_description.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade1][description];
                upgrade_2_description.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade2][description];

                UpgradeBox.GetComponent<Animator>().ResetTrigger("Close");
                UpgradeBox.GetComponent<Animator>().SetTrigger("PopUp");
                break;
            default:
                upgrade1 = Random.Range(0, GetComponent<UpgradesTextList>().UpgradeText.Count);
                upgrade2 = Random.Range(0, GetComponent<UpgradesTextList>().UpgradeText.Count);
                while (upgrade2 == upgrade1)
                {
                    upgrade2 = Random.Range(0, GetComponent<UpgradesTextList>().UpgradeText.Count);
                }
                upgrade3 = Random.Range(0, GetComponent<UpgradesTextList>().UpgradeText.Count);
                while (upgrade3 == upgrade2 || upgrade3 == upgrade1)
                {
                    upgrade3 = Random.Range(0, GetComponent<UpgradesTextList>().UpgradeText.Count);
                }

                icon1.sprite = GetComponent<UpgradesTextList>().icons[upgrade1];
                icon2.sprite = GetComponent<UpgradesTextList>().icons[upgrade2];
                icon3.sprite = GetComponent<UpgradesTextList>().icons[upgrade3];

                upgrade_1_name.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade1][name];
                upgrade_2_name.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade2][name];
                upgrade_3_name.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade3][name];
                upgrade_1_description.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade1][description];
                upgrade_2_description.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade2][description];
                upgrade_3_description.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade3][description];

                UpgradeBox.GetComponent<Animator>().ResetTrigger("Close");
                UpgradeBox.GetComponent<Animator>().SetTrigger("PopUp");
                break;
        }
    }

    public void StartBox()
    {
        isOpen = true;
        Time.timeScale = 0;
        GetComponent<Interface>().isInUpgradeBox = true;

        if (player.GetComponent<UpgradesList>().weaponsAugmented < 5)
        {
            augment = Random.Range(0, player.GetComponent<UpgradesList>().Augment.Count);
            icon4.sprite = GetComponent<UpgradesTextList>().augmentIcons[augment];
            augment_name.text = GetComponent<UpgradesTextList>().AugmentText[augment] + " Chip";
            augment_description.text = "Augment material for the " + GetComponent<UpgradesTextList>().AugmentText[augment];
        }
        else
        {
            augment_name.text = "Pouch of Sun Pieces";
            augment_description.text = "Get 200 sun pieces";
            buttonAugment.SetActive(false);
            buttonAugmentFiller.SetActive(true);
        }

        upgrade1 = Random.Range(3, 14);
        upgrade2 = Random.Range(3, 14);
        while (upgrade2 == upgrade1)
        {
            upgrade2 = Random.Range(3, 14);
        }
        upgrade3 = Random.Range(3, 14);
        while (upgrade3 == upgrade2 || upgrade3 == upgrade1)
        {
            upgrade3 = Random.Range(3, 14);
        }

        icon1.sprite = GetComponent<UpgradesTextList>().icons[upgrade1];
        icon2.sprite = GetComponent<UpgradesTextList>().icons[upgrade2];
        icon3.sprite = GetComponent<UpgradesTextList>().icons[upgrade3];

        upgrade_1_name.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade1][name];
        upgrade_2_name.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade2][name];
        upgrade_3_name.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade3][name];
        upgrade_1_description.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade1][description];
        upgrade_2_description.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade2][description];
        upgrade_3_description.text = GetComponent<UpgradesTextList>().UpgradeText[upgrade3][description];

        UpgradeBox.GetComponent<Animator>().ResetTrigger("Close");
        UpgradeBox.GetComponent<Animator>().SetTrigger("PopUp");
    }

    public void UpgradeBoxClose1()
    {
        player.GetComponent<UpgradesList>().Upgrade[upgrade1]();

        Time.timeScale = 1;
        UpgradeBoxAnimator.ResetTrigger("PopUp");
        UpgradeBoxAnimator.SetTrigger("Close");

        isOpen = false;
        GetComponent<Interface>().isInUpgradeBox = false;
    }

    public void UpgradeBoxClose2()
    { 
        player.GetComponent<UpgradesList>().Upgrade[upgrade2]();

        Time.timeScale = 1;
        UpgradeBoxAnimator.ResetTrigger("PopUp");
        UpgradeBoxAnimator.SetTrigger("Close");

        isOpen = false;
        GetComponent<Interface>().isInUpgradeBox = false;
    }

    public void UpgradeBoxClose3()
    {
        player.GetComponent<UpgradesList>().Upgrade[upgrade3]();

        Time.timeScale = 1;
        UpgradeBoxAnimator.ResetTrigger("PopUp");
        UpgradeBoxAnimator.SetTrigger("Close");

        isOpen = false;
        GetComponent<Interface>().isInUpgradeBox = false;
    }

    public void FillerUpgradeBoxClose1()
    {
        player.GetComponent<UpgradesList>().FillerUpgrade[0]();

        Time.timeScale = 1;
        UpgradeBoxAnimator.ResetTrigger("PopUp");
        UpgradeBoxAnimator.SetTrigger("Close");

        isOpen = false;
        GetComponent<Interface>().isInUpgradeBox = false;
    }

    public void FillerUpgradeBoxClose2()
    {
        player.GetComponent<UpgradesList>().FillerUpgrade[1]();

        Time.timeScale = 1;
        UpgradeBoxAnimator.ResetTrigger("PopUp");
        UpgradeBoxAnimator.SetTrigger("Close");

        isOpen = false;
        GetComponent<Interface>().isInUpgradeBox = false;
    }

    public void FillerUpgradeBoxClose3()
    {
        player.GetComponent<UpgradesList>().FillerUpgrade[2]();

        Time.timeScale = 1;
        UpgradeBoxAnimator.ResetTrigger("PopUp");
        UpgradeBoxAnimator.SetTrigger("Close");

        isOpen = false;
        GetComponent<Interface>().isInUpgradeBox = false;
    }

    public void AugmentUpgradeClose()
    {
        if (player.GetComponent<UpgradesList>().AugmentLevel[augment] > 0)
        {
            if (lucky)
            {
                player.GetComponent<UpgradesList>().AugmentLevel[player.GetComponent<UpgradesList>().availableAugments[augmentLucky]]++;
            }
            else
            {
                player.GetComponent<UpgradesList>().AugmentLevel[augment]++;
            }
            player.GetComponent<UpgradesList>().augmentLevels[player.GetComponent<UpgradesList>().AugmentLevel[augment] - 2 + player.GetComponent<UpgradesList>().iconsIndex[augment] * 3].sprite = player.GetComponent<UpgradesList>().augmented;
            if (player.GetComponent<UpgradesList>().AugmentLevel[augment] >= 4)
            {
                player.GetComponent<UpgradesList>().weaponsIcons[player.GetComponent<UpgradesList>().iconsIndex[augment]].sprite = GetComponent<UpgradesTextList>().augmentIcons[augment];
                player.GetComponent<UpgradesList>().Augment[augment]();
                player.GetComponent<UpgradesList>().Augment.Remove(player.GetComponent<UpgradesList>().Augment[augment]);
                player.GetComponent<UpgradesList>().AugmentLevel.Remove(player.GetComponent<UpgradesList>().AugmentLevel[augment]);
                GetComponent<UpgradesTextList>().AugmentText.Remove(GetComponent<UpgradesTextList>().AugmentText[augment]);
                GetComponent<UpgradesTextList>().augmentIcons.Remove(GetComponent<UpgradesTextList>().augmentIcons[augment]);
            }


            Time.timeScale = 1;
            UpgradeBoxAnimator.ResetTrigger("PopUp");
            UpgradeBoxAnimator.SetTrigger("Close");

            isOpen = false;
            GetComponent<Interface>().isInUpgradeBox = false;
        }
        else
        {
            // play sound
            StopCoroutine("ErrorFade");
            StartCoroutine("ErrorFade");
        }
    }

    public void AugmentFillerUpgradeClose()
    {
        player.GetComponent<UpgradesList>().AugmentFiler();

        Time.timeScale = 1;
        UpgradeBoxAnimator.ResetTrigger("PopUp");
        UpgradeBoxAnimator.SetTrigger("Close");

        isOpen = false;
        GetComponent<Interface>().isInUpgradeBox = false;
    }

    IEnumerator ErrorFade()
    {
        errorText.GetComponent<Animator>().SetBool("GetOut", true);
        yield return new WaitForEndOfFrame();
        errorText.GetComponent<Animator>().SetBool("GetOut", false);
        errorText.GetComponent<Animator>().SetTrigger("PopUp");
        yield return new WaitForSecondsRealtime(4);
        errorText.GetComponent<Animator>().SetBool("GetOut", true);
    }

}
