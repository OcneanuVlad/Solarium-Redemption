using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Deathscreen : MonoBehaviour
{
    public Text text1;
    public void Text1MouseOverEnter()
    {
        text1.color = new Color(0.78f, 0.26f, 0);
    }

    public void Text1MouseOverExit()
    {
        text1.color = new Color(0, 0, 0.08f);
    }

    public void Continue()
    {
        Time.timeScale = 1;
        GetComponent<UpgradeBoxPopUp>().isOpen = true;
        SceneManager.LoadScene("Start Menu");
    }
}
