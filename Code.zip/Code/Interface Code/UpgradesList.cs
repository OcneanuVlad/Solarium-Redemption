using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpgradesList : MonoBehaviour
{
    //public float dropChance = 5f;
    //[HideInInspector] public float badLuckProtection = 0;

    [HideInInspector] public int weaponsEquipped;
    [HideInInspector] public int[] weapons;
    private int index = 0;
    [HideInInspector] public int passivesEquiped;
    [HideInInspector] public int weaponsAugmented;

    public GameObject gameManager;

    [HideInInspector] public int enemyCounter = 0;

    public List<AugmentMethod> Augment;
    public List<int> availableAugments;
    public List<int> AugmentLevel;
    public List<UpgradeMethod> Upgrade;
    public List<FillerUpgradeMethod> FillerUpgrade;

    public delegate void AugmentMethod();
    public delegate void UpgradeMethod();
    public delegate void FillerUpgradeMethod();

    [HideInInspector] public float upgradeXP = 0;
    [HideInInspector] public float damageReduction = 0;

    public Sprite emptyIcon;
    public Image[] weaponsIcons;

    [Header("UI elements")]
    public GameObject rayImage;
    public GameObject rocketsImage;
    public Image[] weaponsLevels;
    public Image[] augmentLevels;
    public Sprite augmented;
    public Sprite leveled;
    public GameObject[] levelObjects;
    public GameObject[] augmentObjects;
    [HideInInspector] public int[] iconsIndex;


    // attack spawners
    [Header("Attack spawners")]
    public GameObject piercingSpikesSpawner;
    public GameObject lightningSpawner;
    public GameObject rocketSpawner;
    public GameObject swordSpawner;
    public GameObject droneSpawner;
    public GameObject laserSpawner;
    public GameObject grenadeSpawner;
    public GameObject spiralSpawner;
    public GameObject meteorSpawner;
    public GameObject splitSpawner;
    public GameObject plasmaSpawner;
    public GameObject fieldSpawner;
    public GameObject bouncySpawner;

    // active attack spawners
    [Header("Active attack spawners")]
    public GameObject raySpawner;
    public GameObject minigunSpawner;
    public GameObject activeRocketSpawner;

    // Augment
    private int piercingSpikesAugment = 0;
    private int lightningAugment = 0;
    private int rocketAugment = 0;
    private int swordAugment = 0;
    private int droneAugment = 0;
    private int laserAugment = 0;
    private int grenadeAugment = 0;
    private int spiralAugment = 0;
    private int meteorAugment = 0;
    private int splitAugment = 0;
    private int plasmaAugment = 0;
    private int fieldAugment = 0;
    private int bouncyAugment = 0;
    private int rayAugment = 0;
    private int minigunAugment = 0;
    private int activeRocketAugment = 0;


    // upgrade levels
    [HideInInspector] public int piercingSpikesLevel = 0;
    [HideInInspector] public int healthUpgradeLevel = 0;
    [HideInInspector] public int movementSpeedLevel = 0;
    [HideInInspector] public int projectileNumberLevel = 0;
    [HideInInspector] public int lightningLevel = 0;
    [HideInInspector] public int rocketLevel = 0;
    [HideInInspector] public int swordLevel = 0;
    [HideInInspector] public int droneLevel = 0;
    [HideInInspector] public int laserLevel = 0;
    [HideInInspector] public int grenadeLevel = 0;
    [HideInInspector] public int spiralLevel = 0;
    [HideInInspector] public int meteorLevel = 0;
    [HideInInspector] public int splitLevel = 0;
    [HideInInspector] public int plasmaLevel = 0;
    [HideInInspector] public int fieldLevel = 0;
    [HideInInspector] public int bouncyLevel = 0;
    [HideInInspector] public int cooldownLevel = 0;
    [HideInInspector] public int attackLevel = 0;
    [HideInInspector] public int knockbackLevel = 0;
    [HideInInspector] public int projectileSpeedLevel = 0;
    [HideInInspector] public int projectileSizeLevel = 0;
    [HideInInspector] public int upgradeXPlevel = 0;
    [HideInInspector] public int pickupRangeLevel = 0;
    [HideInInspector] public int damageReductionLevel = 0;
    [HideInInspector] public int healRegenLevel = 0;

    // active upgrade levels
    [HideInInspector] public int rayLevel = 0;
    [HideInInspector] public int minigunLevel = 0;
    [HideInInspector] public int activeRocketLevel = 0;


    private void Start()
    {
        weaponsAugmented = 0;
        weaponsEquipped = 0;
        passivesEquiped = 0;

        iconsIndex = new int[11];
        weapons = new int[5];
        CreateList();

        gameManager.GetComponent<UpgradeBoxPopUp>().StartBox();
    }

    void CreateList()
    {
        availableAugments = new List<int>();

        AugmentLevel = new List<int>();

        //AugmentLevel.Add(piercingSpikesAugment);
        AugmentLevel.Add(lightningAugment);
        AugmentLevel.Add(rocketAugment);
        AugmentLevel.Add(swordAugment);
        AugmentLevel.Add(droneAugment);
        AugmentLevel.Add(laserAugment);
        AugmentLevel.Add(grenadeAugment);
        AugmentLevel.Add(spiralAugment);
        AugmentLevel.Add(meteorAugment);
        AugmentLevel.Add(splitAugment);
        AugmentLevel.Add(plasmaAugment);
        AugmentLevel.Add(fieldAugment);
        //AugmentLevel.Add(bouncyAugment);
        //AugmentLevel.Add(rayAugment);
        /*AugmentLevel.Add(minigunAugment);
        AugmentLevel.Add(activeRocketAugment);*/

        Augment = new List<AugmentMethod>();

        //Augment.Add(Augment0);
        Augment.Add(Augment1);
        Augment.Add(Augment2);
        Augment.Add(Augment3);
        Augment.Add(Augment4);
        Augment.Add(Augment5);
        Augment.Add(Augment6);
        Augment.Add(Augment7);
        Augment.Add(Augment8);
        Augment.Add(Augment9);
        Augment.Add(Augment10);
        Augment.Add(Augment11);
        //Augment.Add(Augment12);
        //Augment.Add(Augment13);
        /*Augment.Add(Augment14);
        Augment.Add(Augment15);*/

        FillerUpgrade = new List<FillerUpgradeMethod>();

        FillerUpgrade.Add(FillerUpgrade1);
        FillerUpgrade.Add(FillerUpgrade2);
        FillerUpgrade.Add(FillerUpgrade3);

        Upgrade = new List<UpgradeMethod>();

        Upgrade.Add(Upgrade0);
        Upgrade.Add(Upgrade1);
        Upgrade.Add(Upgrade2);
        //Upgrade.Add(Upgrade3);
        Upgrade.Add(Upgrade4);
        Upgrade.Add(Upgrade5);
        Upgrade.Add(Upgrade6);
        Upgrade.Add(Upgrade7);
        Upgrade.Add(Upgrade8);
        Upgrade.Add(Upgrade9);
        Upgrade.Add(Upgrade10);
        Upgrade.Add(Upgrade11);
        Upgrade.Add(Upgrade12);
        Upgrade.Add(Upgrade13);
        Upgrade.Add(Upgrade14);
        //Upgrade.Add(Upgrade15);
        /*Upgrade.Add(Upgrade16);
        Upgrade.Add(Upgrade17);
        Upgrade.Add(Upgrade18);*/
        Upgrade.Add(Upgrade19);
        Upgrade.Add(Upgrade20);
        Upgrade.Add(Upgrade21);
        //Upgrade.Add(Upgrade22);
        Upgrade.Add(Upgrade23);
        Upgrade.Add(Upgrade24);
        Upgrade.Add(Upgrade25);
        Upgrade.Add(Upgrade26);
        Upgrade.Add(Upgrade27);
    }

    void Upgrade0()
    {
        projectileNumberLevel++;
        CheckIfRoomForPassives();
        gameManager.GetComponent<AttackStats>().numberOfProjectiles++;

        if (projectileNumberLevel == 2)
        {
            Upgrade.Remove(Upgrade0);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text0);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon0);
        }
    }

    void Upgrade1()
    {
        healthUpgradeLevel++;
        CheckIfRoomForPassives();
        float currentHealthPercent = (gameObject.GetComponent<PlayerHealth>().currentHealth / gameObject.GetComponent<PlayerHealth>().maxHealth) * 100;
        gameObject.GetComponent<PlayerHealth>().maxHealth += (20f / 100f) * gameObject.GetComponent<PlayerHealth>().maxHealth;
        gameObject.GetComponent<PlayerHealth>().currentHealth = (currentHealthPercent / 100f) * gameObject.GetComponent<PlayerHealth>().maxHealth;

        if (healthUpgradeLevel == 5)
        {
            Upgrade.Remove(Upgrade1);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text1);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon1);
        }
    }

    void Upgrade2()
    {
        movementSpeedLevel++;
        CheckIfRoomForPassives();
        gameObject.GetComponent<PlayerMovement>().movementSpeed += (10f / 100f) * gameObject.GetComponent<PlayerMovement>().movementSpeed;

        if (movementSpeedLevel == 3)
        {
            Upgrade.Remove(Upgrade2);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text2);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon2);
        }
    }

    // active upgrade
    void Upgrade3()
    {
        piercingSpikesLevel++;
        switch (piercingSpikesLevel)
        {
            case 1:
                piercingSpikesSpawner.SetActive(true);
                gameManager.GetComponent<UpgradesTextList>().text3[1] = "Increases the damage of piercing spikes by 15% and attack speed by 10%";
                CheckIfRoomForWeapons();
                break;
            case 2:
                piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackDamage += 15 / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackDamage;
                piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackSpeed -= 10 / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackSpeed;
                gameManager.GetComponent<UpgradesTextList>().text3[1] = "Increases the damage of piercing spikes by 15% and projectile speed by 15%";
                break;
            case 3:
                piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackDamage += 15 / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackDamage;
                piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().projectileSpeed -= 15 / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().projectileSpeed;
                gameManager.GetComponent<UpgradesTextList>().text3[1] = "Increases the damage of piercing spikes by 15% and knockback by 30%";
                break;
            case 4:
                piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackDamage += 15 / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackDamage;
                piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().knockbackForce -= 30 / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().knockbackForce;
                gameManager.GetComponent<UpgradesTextList>().text3[1] = "Increases the damage of piercing spikes by 35% and attack speed by 25%";
                break;
            case 5:
                piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackDamage += 35 / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackDamage;
                piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackSpeed -= 25 / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackSpeed;

                Upgrade.Remove(Upgrade3);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text3);
                break;
        }
    }

    void Upgrade4()
    {
        lightningLevel++;
        switch (lightningLevel)
        {
            case 1:
                lightningSpawner.SetActive(true);
                iconsIndex[0] = SetWeaponsIcon(gameManager.GetComponent<UpgradesTextList>().icon3);
                levelObjects[iconsIndex[0]].SetActive(true);
                weaponsLevels[0 + iconsIndex[0] * 5].sprite = leveled;
                gameManager.GetComponent<UpgradesTextList>().text4[1] = "Increases the number of Lightning Strikes by 1";
                CheckIfRoomForWeapons();
                break;
            case 2:
                weaponsLevels[1 + iconsIndex[0] * 5].sprite = leveled;
                lightningSpawner.GetComponent<LightningAttackSpawner>().numberOfProjectiles++;
                gameManager.GetComponent<UpgradesTextList>().text4[1] = "Increases the damage of Lightning Strikes by 25% and attack speed by 15%";
                break;
            case 3:
                weaponsLevels[2 + iconsIndex[0] * 5].sprite = leveled;
                lightningSpawner.GetComponent<LightningAttackSpawner>().attackDamage += 25 / 100 * lightningSpawner.GetComponent<LightningAttackSpawner>().attackDamage;
                lightningSpawner.GetComponent<LightningAttackSpawner>().attackSpeed -= 15 / 100 * lightningSpawner.GetComponent<LightningAttackSpawner>().attackSpeed;
                gameManager.GetComponent<UpgradesTextList>().text4[1] = "Increases the number of Lightning Strikes by 1 and attack speed by 25%";
                break;
            case 4:
                weaponsLevels[3 + iconsIndex[0] * 5].sprite = leveled;
                lightningSpawner.GetComponent<LightningAttackSpawner>().attackSpeed -= 25 / 100 * lightningSpawner.GetComponent<LightningAttackSpawner>().attackSpeed;
                lightningSpawner.GetComponent<LightningAttackSpawner>().numberOfProjectiles++;
                gameManager.GetComponent<UpgradesTextList>().text4[1] = "Increases the number of Lightning Strikes by 2 and damage by 15%";
                break;
            case 5:
                weaponsLevels[4 + iconsIndex[0] * 5].sprite = leveled;
                augmentObjects[iconsIndex[0]].SetActive(true);
                lightningSpawner.GetComponent<LightningAttackSpawner>().attackDamage += 15 / 100 * lightningSpawner.GetComponent<LightningAttackSpawner>().attackDamage;
                lightningSpawner.GetComponent<LightningAttackSpawner>().numberOfProjectiles += 2;
                AugmentLevel[0]++;
                availableAugments.Add(0);

                Upgrade.Remove(Upgrade4);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text4);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon3);
                break;
        }
    }

    void Upgrade5()
    {
        rocketLevel++;
        switch (rocketLevel)
        {
            case 1:
                rocketSpawner.SetActive(true);
                iconsIndex[1] = SetWeaponsIcon(gameManager.GetComponent<UpgradesTextList>().icon4);
                levelObjects[iconsIndex[1]].SetActive(true);
                weaponsLevels[0 + iconsIndex[1] * 5].sprite = leveled;
                gameManager.GetComponent<UpgradesTextList>().text5[1] = "Increases the damage of Rockets by 15% and projectile speed by 25%";
                CheckIfRoomForWeapons();
                break;
            case 2:
                weaponsLevels[1 + iconsIndex[1] * 5].sprite = leveled;
                rocketSpawner.GetComponent<RocketAttackSpawner>().attackDamage += 15 / 100 * rocketSpawner.GetComponent<RocketAttackSpawner>().attackDamage;
                rocketSpawner.GetComponent<RocketAttackSpawner>().projectileSpeed += 25 / 100 * rocketSpawner.GetComponent<RocketAttackSpawner>().projectileSpeed;
                gameManager.GetComponent<UpgradesTextList>().text5[1] = "Increases the number of Rockets by 1 and size by 10%";
                break;
            case 3:
                weaponsLevels[2 + iconsIndex[1] * 5].sprite = leveled;
                rocketSpawner.GetComponent<RocketAttackSpawner>().scale += 10 / 100 * rocketSpawner.GetComponent<RocketAttackSpawner>().scale;
                rocketSpawner.GetComponent<RocketAttackSpawner>().numberOfProjectiles++;
                gameManager.GetComponent<UpgradesTextList>().text5[1] = "Increases the speed of Rockets by 35%";
                break;
            case 4:
                weaponsLevels[3 + iconsIndex[1] * 5].sprite = leveled;
                rocketSpawner.GetComponent<RocketAttackSpawner>().projectileSpeed += 35 / 100 * rocketSpawner.GetComponent<RocketAttackSpawner>().projectileSpeed;
                gameManager.GetComponent<UpgradesTextList>().text5[1] = "Increases the number of Rockets by 2 and size by 25%";
                break;
            case 5:
                weaponsLevels[4 + iconsIndex[1] * 5].sprite = leveled;
                augmentObjects[iconsIndex[1]].SetActive(true);
                rocketSpawner.GetComponent<RocketAttackSpawner>().scale += 25 / 100 * rocketSpawner.GetComponent<RocketAttackSpawner>().scale;
                rocketSpawner.GetComponent<RocketAttackSpawner>().numberOfProjectiles += 2;
                AugmentLevel[1]++;
                availableAugments.Add(1);

                Upgrade.Remove(Upgrade5);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text5);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon4);
                break;
        }
    }

    void Upgrade6()
    {
        swordLevel++;
        switch (swordLevel)
        {
            case 1:
                swordSpawner.SetActive(true);
                iconsIndex[2] = SetWeaponsIcon(gameManager.GetComponent<UpgradesTextList>().icon5);
                levelObjects[iconsIndex[2]].SetActive(true);
                weaponsLevels[0 + iconsIndex[2] * 5].sprite = leveled;
                gameManager.GetComponent<UpgradesTextList>().text6[1] = "Increases the attack speed of the energy Sword by 25%";
                CheckIfRoomForWeapons();
                break;
            case 2:
                weaponsLevels[1 + iconsIndex[2] * 5].sprite = leveled;
                swordSpawner.GetComponent<SwordAttackSpawner>().attackSpeed -= 25 / 100 * swordSpawner.GetComponent<SwordAttackSpawner>().attackSpeed;
                gameManager.GetComponent<UpgradesTextList>().text6[1] = "Increases the damage of the energy Sword by 30%";
                break;
            case 3:
                weaponsLevels[2 + iconsIndex[2] * 5].sprite = leveled;
                swordSpawner.GetComponent<SwordAttackSpawner>().attackDamage += 30 / 100 * swordSpawner.GetComponent<SwordAttackSpawner>().attackDamage;
                gameManager.GetComponent<UpgradesTextList>().text6[1] = "Increases the size of the energy Sword by 25%";
                break;
            case 4:
                weaponsLevels[3 + iconsIndex[2] * 5].sprite = leveled;
                swordSpawner.transform.localScale += swordSpawner.transform.localScale * 0.25f;
                gameManager.GetComponent<UpgradesTextList>().text6[1] = "Increases the number of slashes of the energy Sword by 1 and attack speed by 35%";
                break;
            case 5:
                weaponsLevels[4 + iconsIndex[2] * 5].sprite = leveled;
                augmentObjects[iconsIndex[2]].SetActive(true);
                swordSpawner.GetComponent<SwordAttackSpawner>().attackSpeed -= 35 / 100 * swordSpawner.GetComponent<SwordAttackSpawner>().attackSpeed;
                swordSpawner.GetComponent<SwordAttackSpawner>().isUpgraded = true;
                AugmentLevel[2]++;
                availableAugments.Add(2);

                Upgrade.Remove(Upgrade6);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text6);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon5);
                break;
        }
    }

    void Upgrade7()
    {
        droneLevel++;
        switch (droneLevel)
        {
            case 1:
                droneSpawner.SetActive(true);
                iconsIndex[3] = SetWeaponsIcon(gameManager.GetComponent<UpgradesTextList>().icon6);
                levelObjects[iconsIndex[3]].SetActive(true);
                weaponsLevels[0 + iconsIndex[3] * 5].sprite = leveled;
                gameManager.GetComponent<UpgradesTextList>().text7[1] = "Increases the number of Drones by 2";
                CheckIfRoomForWeapons();
                break;
            case 2:
                weaponsLevels[1 + iconsIndex[3] * 5].sprite = leveled;
                droneSpawner.transform.GetChild(0).transform.GetChild(1).gameObject.SetActive(true);
                droneSpawner.transform.GetChild(0).transform.GetChild(6).gameObject.SetActive(true);
                gameManager.GetComponent<UpgradesTextList>().text7[1] = "Increases the number of Drones by 2 and speed by 10%";
                break;
            case 3:
                weaponsLevels[2 + iconsIndex[3] * 5].sprite = leveled;
                droneSpawner.transform.GetChild(0).transform.GetChild(2).gameObject.SetActive(true);
                droneSpawner.transform.GetChild(0).transform.GetChild(5).gameObject.SetActive(true);
                droneSpawner.GetComponent<RotatingDroneAttackSpawner>().spinSpeed += 10 / 100 * droneSpawner.GetComponent<RotatingDroneAttackSpawner>().spinSpeed;
                gameManager.GetComponent<UpgradesTextList>().text7[1] = "Increases the number of Drones by 2 and speed by 15%";

                break;
            case 4:
                weaponsLevels[3 + iconsIndex[3] * 5].sprite = leveled;
                droneSpawner.transform.GetChild(0).transform.GetChild(4).gameObject.SetActive(true);
                droneSpawner.transform.GetChild(0).transform.GetChild(7).gameObject.SetActive(true);
                droneSpawner.GetComponent<RotatingDroneAttackSpawner>().spinSpeed += 15 / 100 * droneSpawner.GetComponent<RotatingDroneAttackSpawner>().spinSpeed;
                gameManager.GetComponent<UpgradesTextList>().text7[1] = "Increases the speed of Drones by 50%";
                break;
            case 5:
                weaponsLevels[4 + iconsIndex[3] * 5].sprite = leveled;
                augmentObjects[iconsIndex[3]].SetActive(true);
                droneSpawner.GetComponent<RotatingDroneAttackSpawner>().spinSpeed += 50 / 100 * droneSpawner.GetComponent<RotatingDroneAttackSpawner>().spinSpeed;
                AugmentLevel[3]++;
                availableAugments.Add(3);

                Upgrade.Remove(Upgrade7);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text7);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon6);
                break;
        }
    }

    void Upgrade8()
    {
        laserLevel++;
        switch (laserLevel)
        {
            case 1:
                laserSpawner.SetActive(true);
                iconsIndex[4] = SetWeaponsIcon(gameManager.GetComponent<UpgradesTextList>().icon7);
                levelObjects[iconsIndex[4]].SetActive(true);
                weaponsLevels[0 + iconsIndex[4] * 5].sprite = leveled;
                gameManager.GetComponent<UpgradesTextList>().text8[1] = "Increases the damage of Lasers by 15% and attack speed by 20%";
                CheckIfRoomForWeapons();
                break;
            case 2:
                weaponsLevels[1 + iconsIndex[4] * 5].sprite = leveled;
                laserSpawner.GetComponent<LaserAttackSpawner>().attackDamage += 15 / 100 * laserSpawner.GetComponent<LaserAttackSpawner>().attackDamage;
                laserSpawner.GetComponent<LaserAttackSpawner>().attackSpeed -= 20 / 100 * laserSpawner.GetComponent<LaserAttackSpawner>().attackSpeed;
                gameManager.GetComponent<UpgradesTextList>().text8[1] = "Increases the speed of Lasers by 25% and attack speed by 10%";
                break;
            case 3:
                weaponsLevels[2 + iconsIndex[4] * 5].sprite = leveled;
                laserSpawner.GetComponent<LaserAttackSpawner>().projectileSpeed += 25 / 100 * laserSpawner.GetComponent<LaserAttackSpawner>().projectileSpeed;
                laserSpawner.GetComponent<LaserAttackSpawner>().attackSpeed -= 10 / 100 * laserSpawner.GetComponent<LaserAttackSpawner>().attackSpeed;
                gameManager.GetComponent<UpgradesTextList>().text8[1] = "Increases the damage of Lasers by 20%";
                break;
            case 4:
                weaponsLevels[3 + iconsIndex[4] * 5].sprite = leveled;
                laserSpawner.GetComponent<LaserAttackSpawner>().attackDamage += 20 / 100 * laserSpawner.GetComponent<LaserAttackSpawner>().attackDamage;
                gameManager.GetComponent<UpgradesTextList>().text8[1] = "Increases the attack speed of Lasers by 35%";
                break;
            case 5:
                weaponsLevels[4 + iconsIndex[4] * 5].sprite = leveled;
                augmentObjects[iconsIndex[4]].SetActive(true);
                laserSpawner.GetComponent<LaserAttackSpawner>().attackSpeed -= 35 / 100 * laserSpawner.GetComponent<LaserAttackSpawner>().attackSpeed;
                AugmentLevel[4]++;
                availableAugments.Add(4);

                Upgrade.Remove(Upgrade8);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text8);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon7);
                break;
        }
    }

    void Upgrade9()
    {
        grenadeLevel++;
        switch (grenadeLevel)
        {
            case 1:
                grenadeSpawner.SetActive(true);
                iconsIndex[5] = SetWeaponsIcon(gameManager.GetComponent<UpgradesTextList>().icon8);
                levelObjects[iconsIndex[5]].SetActive(true);
                weaponsLevels[0 + iconsIndex[5] * 5].sprite = leveled;
                gameManager.GetComponent<UpgradesTextList>().text9[1] = "Increases the damage of Goop by 25% and duration by 20%";
                CheckIfRoomForWeapons();
                break;
            case 2:
                weaponsLevels[1 + iconsIndex[5] * 5].sprite = leveled;
                grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().attackDamage += 25 / 100 * grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().attackDamage;
                grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().duration += 20 / 100 * grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().duration;
                gameManager.GetComponent<UpgradesTextList>().text9[1] = "Increases the size of Goop by 15% and duration by 10%";
                break;
            case 3:
                weaponsLevels[2 + iconsIndex[5] * 5].sprite = leveled;
                grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().scale += 15 / 100 * grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().scale;
                grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().duration += 10 / 100 * grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().duration;
                gameManager.GetComponent<UpgradesTextList>().text9[1] = "Increases the duration of Goop by 30%";
                break;
            case 4:
                weaponsLevels[3 + iconsIndex[5] * 5].sprite = leveled;
                grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().duration += 30 / 100 * grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().duration;
                gameManager.GetComponent<UpgradesTextList>().text9[1] = "Increases the damage of Goop by 15% and attack speed by 30%";
                break;
            case 5:
                weaponsLevels[4 + iconsIndex[5] * 5].sprite = leveled;
                augmentObjects[iconsIndex[5]].SetActive(true);
                grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().attackDamage += 15 / 100 * grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().attackDamage;
                grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().attackSpeed -= 30 / 100 * grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().attackSpeed;
                AugmentLevel[5]++;
                availableAugments.Add(5);

                Upgrade.Remove(Upgrade9);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text9);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon8);
                break;
        }
    }

    void Upgrade10()
    {
        spiralLevel++;
        switch (spiralLevel)
        {
            case 1:
                spiralSpawner.SetActive(true);
                iconsIndex[6] = SetWeaponsIcon(gameManager.GetComponent<UpgradesTextList>().icon9);
                levelObjects[iconsIndex[6]].SetActive(true);
                weaponsLevels[0 + iconsIndex[6] * 5].sprite = leveled;
                gameManager.GetComponent<UpgradesTextList>().text10[1] = "Increases the damage of Scythe by 10% and attack speed by 15%";
                CheckIfRoomForWeapons();
                break;
            case 2:
                weaponsLevels[1 + iconsIndex[6] * 5].sprite = leveled;
                spiralSpawner.GetComponent<SpiralAttackSpawner>().attackDamage += 10 / 100 * spiralSpawner.GetComponent<SpiralAttackSpawner>().attackDamage;
                spiralSpawner.GetComponent<SpiralAttackSpawner>().attackSpeed -= 15 / 100 * spiralSpawner.GetComponent<SpiralAttackSpawner>().attackSpeed;
                gameManager.GetComponent<UpgradesTextList>().text10[1] = "Increases the size of Scythe by 30%";
                break;
            case 3:
                weaponsLevels[2 + iconsIndex[6] * 5].sprite = leveled;
                spiralSpawner.GetComponent<SpiralAttackSpawner>().scale += 30 / 100 * spiralSpawner.GetComponent<SpiralAttackSpawner>().scale;
                gameManager.GetComponent<UpgradesTextList>().text10[1] = "Increases the damage of Scythe by 20% and attack speed by 10%";
                break;
            case 4:
                weaponsLevels[3 + iconsIndex[6] * 5].sprite = leveled;
                spiralSpawner.GetComponent<SpiralAttackSpawner>().attackDamage += 20 / 100 * spiralSpawner.GetComponent<SpiralAttackSpawner>().attackDamage;
                spiralSpawner.GetComponent<SpiralAttackSpawner>().attackSpeed -= 10 / 100 * spiralSpawner.GetComponent<SpiralAttackSpawner>().attackSpeed;
                gameManager.GetComponent<UpgradesTextList>().text10[1] = "Increases the attack speed of Scythe by 30%";
                break;
            case 5:
                weaponsLevels[4 + iconsIndex[6] * 5].sprite = leveled;
                augmentObjects[iconsIndex[6]].SetActive(true);
                spiralSpawner.GetComponent<SpiralAttackSpawner>().attackSpeed -= 30 / 100 * spiralSpawner.GetComponent<SpiralAttackSpawner>().attackSpeed;
                AugmentLevel[6]++;
                availableAugments.Add(6);

                Upgrade.Remove(Upgrade10);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text10);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon9);
                break;
        }
    }

    void Upgrade11()
    {
        meteorLevel++;
        switch (meteorLevel)
        {
            case 1:
                meteorSpawner.SetActive(true);
                iconsIndex[7] = SetWeaponsIcon(gameManager.GetComponent<UpgradesTextList>().icon10);
                levelObjects[iconsIndex[7]].SetActive(true);
                weaponsLevels[0 + iconsIndex[7] * 5].sprite = leveled;
                gameManager.GetComponent<UpgradesTextList>().text11[1] = "Increases the damage of Meteors by 20% and attack speed by 10%";
                CheckIfRoomForWeapons();
                break;
            case 2:
                weaponsLevels[1 + iconsIndex[7] * 5].sprite = leveled;
                meteorSpawner.GetComponent<MeteorAttackSpawner>().attackDamage += 20 / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().attackDamage;
                meteorSpawner.GetComponent<MeteorAttackSpawner>().attackSpeed -= 10 / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().attackSpeed;
                break;
            case 3:
                weaponsLevels[2 + iconsIndex[7] * 5].sprite = leveled;
                meteorSpawner.GetComponent<MeteorAttackSpawner>().attackDamage += 25 / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().attackDamage;
                meteorSpawner.GetComponent<MeteorAttackSpawner>().attackSpeed -= 20 / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().attackSpeed;
                break;
            case 4:
                weaponsLevels[3 + iconsIndex[7] * 5].sprite = leveled;
                meteorSpawner.GetComponent<MeteorAttackSpawner>().attackDamage += 25 / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().attackDamage;
                meteorSpawner.GetComponent<MeteorAttackSpawner>().attackSpeed -= 20 / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().attackSpeed;
                break;
            case 5:
                weaponsLevels[4 + iconsIndex[7] * 5].sprite = leveled;
                augmentObjects[iconsIndex[7]].SetActive(true);
                meteorSpawner.GetComponent<MeteorAttackSpawner>().attackDamage += 25 / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().attackDamage;
                meteorSpawner.GetComponent<MeteorAttackSpawner>().attackSpeed -= 20 / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().attackSpeed;
                AugmentLevel[7]++;
                availableAugments.Add(7);

                Upgrade.Remove(Upgrade11);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text11);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon10);
                break;
        }
    }

    void Upgrade12()
    {
        splitLevel++;
        switch (splitLevel)
        {
            case 1:
                splitSpawner.SetActive(true);
                iconsIndex[8] = SetWeaponsIcon(gameManager.GetComponent<UpgradesTextList>().icon11);
                levelObjects[iconsIndex[8]].SetActive(true);
                weaponsLevels[0 + iconsIndex[8] * 5].sprite = leveled;
                gameManager.GetComponent<UpgradesTextList>().text12[1] = "Increases the damage of Split by 25% and attack speed by 20%";
                CheckIfRoomForWeapons();
                break;
            case 2:
                weaponsLevels[1 + iconsIndex[8] * 5].sprite = leveled;
                splitSpawner.GetComponent<SplitAttackSpawner>().attackDamage += 25 / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().attackDamage;
                splitSpawner.GetComponent<SplitAttackSpawner>().attackSpeed -= 20 / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().attackSpeed;
                break;
            case 3:
                weaponsLevels[2 + iconsIndex[8] * 5].sprite = leveled;
                splitSpawner.GetComponent<SplitAttackSpawner>().attackDamage += 25 / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().attackDamage;
                splitSpawner.GetComponent<SplitAttackSpawner>().attackSpeed -= 20 / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().attackSpeed;
                break;
            case 4:
                weaponsLevels[3 + iconsIndex[8] * 5].sprite = leveled;
                splitSpawner.GetComponent<SplitAttackSpawner>().attackDamage += 25 / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().attackDamage;
                splitSpawner.GetComponent<SplitAttackSpawner>().attackSpeed -= 20 / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().attackSpeed;
                break;
            case 5:
                weaponsLevels[4 + iconsIndex[8] * 5].sprite = leveled;
                augmentObjects[iconsIndex[8]].SetActive(true);
                splitSpawner.GetComponent<SplitAttackSpawner>().attackDamage += 25 / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().attackDamage;
                splitSpawner.GetComponent<SplitAttackSpawner>().attackSpeed -= 20 / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().attackSpeed;
                AugmentLevel[8]++;
                availableAugments.Add(8);

                Upgrade.Remove(Upgrade12);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text12);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon11);
                break;
        }
    }

    void Upgrade13()
    {
        plasmaLevel++;
        switch (plasmaLevel)
        {
            case 1:
                plasmaSpawner.SetActive(true);
                iconsIndex[9] = SetWeaponsIcon(gameManager.GetComponent<UpgradesTextList>().icon12);
                levelObjects[iconsIndex[9]].SetActive(true);
                weaponsLevels[0 + iconsIndex[9] * 5].sprite = leveled;
                gameManager.GetComponent<UpgradesTextList>().text13[1] = "Increases the damage of Plasma Ball by 25% and attack speed by 20%";
                CheckIfRoomForWeapons();
                break;
            case 2:
                weaponsLevels[1 + iconsIndex[9] * 5].sprite = leveled;
                plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackDamage += 25 / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackDamage;
                plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackSpeed -= 20 / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackSpeed;
                break;
            case 3:
                weaponsLevels[2 + iconsIndex[9] * 5].sprite = leveled;
                plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackDamage += 25 / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackDamage;
                plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackSpeed -= 20 / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackSpeed;
                break;
            case 4:
                weaponsLevels[3 + iconsIndex[9] * 5].sprite = leveled;
                plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackDamage += 25 / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackDamage;
                plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackSpeed -= 20 / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackSpeed;
                break;
            case 5:
                weaponsLevels[4 + iconsIndex[9] * 5].sprite = leveled;
                augmentObjects[iconsIndex[9]].SetActive(true);
                plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackDamage += 25 / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackDamage;
                plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackSpeed -= 20 / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackSpeed;
                AugmentLevel[9]++;
                availableAugments.Add(9);

                Upgrade.Remove(Upgrade13);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text13);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon12);
                break;
        }
    }

    void Upgrade14()
    {
        fieldLevel++;
        switch (fieldLevel)
        {
            case 1:
                fieldSpawner.SetActive(true);
                iconsIndex[10] = SetWeaponsIcon(gameManager.GetComponent<UpgradesTextList>().icon13);
                levelObjects[iconsIndex[10]].SetActive(true);
                weaponsLevels[0 + iconsIndex[10] * 5].sprite = leveled;
                gameManager.GetComponent<UpgradesTextList>().text14[1] = "Increases the damage of Laser Field by 25% and attack speed by 20%";
                CheckIfRoomForWeapons();
                break;
            case 2:
                weaponsLevels[1 + iconsIndex[10] * 5].sprite = leveled;
                fieldSpawner.GetComponent<FieldAttackSpawner>().attackDamage += 25 / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().attackDamage;
                fieldSpawner.GetComponent<FieldAttackSpawner>().attackSpeed -= 20 / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().attackSpeed;
                break;
            case 3:
                weaponsLevels[2 + iconsIndex[10] * 5].sprite = leveled;
                fieldSpawner.GetComponent<FieldAttackSpawner>().attackDamage += 25 / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().attackDamage;
                fieldSpawner.GetComponent<FieldAttackSpawner>().attackSpeed -= 20 / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().attackSpeed;
                break;
            case 4:
                weaponsLevels[3 + iconsIndex[10] * 5].sprite = leveled;
                fieldSpawner.GetComponent<FieldAttackSpawner>().attackDamage += 25 / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().attackDamage;
                fieldSpawner.GetComponent<FieldAttackSpawner>().attackSpeed -= 20 / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().attackSpeed;
                break;
            case 5:
                weaponsLevels[4 + iconsIndex[10] * 5].sprite = leveled;
                augmentObjects[iconsIndex[10]].SetActive(true);
                fieldSpawner.GetComponent<FieldAttackSpawner>().attackDamage += 25 / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().attackDamage;
                fieldSpawner.GetComponent<FieldAttackSpawner>().attackSpeed -= 20 / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().attackSpeed;
                AugmentLevel[10]++;
                availableAugments.Add(10);

                Upgrade.Remove(Upgrade14);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text14);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon13);
                break;
        }
    }

    void Upgrade15()
    {
        bouncyLevel++;
        switch (bouncyLevel)
        {
            case 1:
                bouncySpawner.SetActive(true);
                gameManager.GetComponent<UpgradesTextList>().text15[1] = "Increases the damage of Bouncy by 25% and attack speed by 20%";
                AugmentLevel[11]++;
                CheckIfRoomForWeapons();
                break;
            case 2:
                bouncySpawner.GetComponent<BouncyAttackSpawner>().attackDamage += 25 / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().attackDamage;
                bouncySpawner.GetComponent<BouncyAttackSpawner>().attackSpeed -= 20 / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().attackSpeed;
                break;
            case 3:
                bouncySpawner.GetComponent<BouncyAttackSpawner>().attackDamage += 25 / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().attackDamage;
                bouncySpawner.GetComponent<BouncyAttackSpawner>().attackSpeed -= 20 / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().attackSpeed;
                break;
            case 4:
                bouncySpawner.GetComponent<BouncyAttackSpawner>().attackDamage += 25 / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().attackDamage;
                bouncySpawner.GetComponent<BouncyAttackSpawner>().attackSpeed -= 20 / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().attackSpeed;
                break;
            case 5:
                bouncySpawner.GetComponent<BouncyAttackSpawner>().attackDamage += 25 / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().attackDamage;
                bouncySpawner.GetComponent<BouncyAttackSpawner>().attackSpeed -= 20 / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().attackSpeed;

                Upgrade.Remove(Upgrade15);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text15);
                break;
        }
    }

    void Upgrade16()
    {
        rayLevel++;
        switch (rayLevel)
        {
            case 1:
                raySpawner.SetActive(true);
                rayImage.SetActive(true);
                gameManager.GetComponent<UpgradesTextList>().text16[1] = "Increases the damage of Ray by 25% and cool off speed by 20%";
                RemoveActiveWeapons();
                break;
            case 2:
                raySpawner.GetComponentInChildren<RayAttackEvent>().attackDamage += 25 / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().attackDamage;
                raySpawner.GetComponentInChildren<RayAttackEvent>().coolOffSpeed -= 20 / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().coolOffSpeed;
                break;
            case 3:
                raySpawner.GetComponentInChildren<RayAttackEvent>().attackDamage += 25 / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().attackDamage;
                raySpawner.GetComponentInChildren<RayAttackEvent>().coolOffSpeed -= 20 / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().coolOffSpeed; 
                break;
            case 4:
                raySpawner.GetComponentInChildren<RayAttackEvent>().attackDamage += 25 / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().attackDamage;
                raySpawner.GetComponentInChildren<RayAttackEvent>().coolOffSpeed -= 20 / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().coolOffSpeed; 
                break;
            case 5:
                raySpawner.GetComponentInChildren<RayAttackEvent>().attackDamage += 25 / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().attackDamage;
                raySpawner.GetComponentInChildren<RayAttackEvent>().coolOffSpeed -= 20 / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().coolOffSpeed;
                AugmentLevel[11]++;

                Upgrade.Remove(Upgrade16);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text16);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon14);
                break;
        }
    }

    void Upgrade17()
    {
        minigunLevel++;
        switch (minigunLevel)
        {
            case 1:
                minigunSpawner.SetActive(true);
                gameManager.GetComponent<UpgradesTextList>().text17[1] = "Increases the damage of Minigun by 25% and number of projectiles by 1";
                //AugmentLevel[13]++;
                RemoveActiveWeapons();
                break;
            case 2:
                minigunSpawner.GetComponent<MinigunAttackSpawner>().attackDamage += 25 / 100 * minigunSpawner.GetComponent<MinigunAttackSpawner>().attackDamage;
                minigunSpawner.GetComponent<MinigunAttackSpawner>().projectileNumber += 1;
                break;
            case 3:
                minigunSpawner.GetComponent<MinigunAttackSpawner>().attackDamage += 25 / 100 * minigunSpawner.GetComponent<MinigunAttackSpawner>().attackDamage;
                minigunSpawner.GetComponent<MinigunAttackSpawner>().projectileNumber += 1;
                break;
            case 4:
                minigunSpawner.GetComponent<MinigunAttackSpawner>().attackDamage += 25 / 100 * minigunSpawner.GetComponent<MinigunAttackSpawner>().attackDamage;
                minigunSpawner.GetComponent<MinigunAttackSpawner>().projectileNumber += 1;
                break;
            case 5:
                minigunSpawner.GetComponent<MinigunAttackSpawner>().attackDamage += 25 / 100 * minigunSpawner.GetComponent<MinigunAttackSpawner>().attackDamage;
                minigunSpawner.GetComponent<MinigunAttackSpawner>().projectileNumber += 1;

                Upgrade.Remove(Upgrade17);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text17);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon15);
                break;
        }
    }

    void Upgrade18()
    {
        activeRocketLevel++;
        switch (activeRocketLevel)
        {
            case 1:
                activeRocketSpawner.SetActive(true);
                rocketsImage.SetActive(true);
                gameManager.GetComponent<UpgradesTextList>().text18[1] = "Increases the damage of Homing Rockets by 25% and reduces cooldown by 20%";
                //AugmentLevel[14]++;
                RemoveActiveWeapons();
                break;
            case 2:
                activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().attackDamage += 25 / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().attackDamage;
                activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().cooldownDuration -= 20 / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().cooldownDuration;
                break;
            case 3:
                activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().attackDamage += 25 / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().attackDamage;
                activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().cooldownDuration -= 20 / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().cooldownDuration;
                break;
            case 4:
                activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().attackDamage += 25 / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().attackDamage;
                activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().cooldownDuration -= 20 / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().cooldownDuration;
                break;
            case 5:
                activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().attackDamage += 25 / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().attackDamage;
                activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().cooldownDuration -= 20 / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().cooldownDuration;

                Upgrade.Remove(Upgrade18);
                gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text18);
                gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon16);
                break;
        }
    }

    void Upgrade19()
    {
        cooldownLevel++;
        CheckIfRoomForPassives();
        DecreaseCooldown(10);

        if (cooldownLevel == 4)
        {
            Upgrade.Remove(Upgrade19);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text19);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon17);
        }
    }

    void Upgrade20()
    {
        projectileSpeedLevel++;
        CheckIfRoomForPassives();
        IncreaseProjectileSpeed(15);

        if (projectileSpeedLevel == 5)
        {
            Upgrade.Remove(Upgrade20);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text20);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon18);
        }
    }

    void Upgrade21()
    {
        attackLevel++;
        CheckIfRoomForPassives();
        IncreaseAttack(10);

        if (attackLevel == 5)
        {
            Upgrade.Remove(Upgrade21);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text21);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon19);
        }
    }

    void Upgrade22()
    {
        knockbackLevel++;
        CheckIfRoomForPassives();
        IncreaseKnockback(7);

        if (knockbackLevel == 5)
        {
            Upgrade.Remove(Upgrade22);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text22);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon20);
        }
    }

    void Upgrade23()
    {
        projectileSizeLevel++;
        CheckIfRoomForPassives();
        IncreaseProjectileSize(10);

        if (projectileSizeLevel == 3)
        {
            Upgrade.Remove(Upgrade23);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text23);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon20);
        }
    }

    void Upgrade24()
    {
        upgradeXPlevel++;
        CheckIfRoomForPassives();
        upgradeXP += 10;

        if (upgradeXPlevel == 5)
        {
            Upgrade.Remove(Upgrade24);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text24);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon21);
        }
    }

    void Upgrade25()
    {
        pickupRangeLevel++;
        CheckIfRoomForPassives();
        gameObject.GetComponentInChildren<CircleCollider2D>().radius += 5;

        if (pickupRangeLevel == 5)
        {
            Upgrade.Remove(Upgrade25);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text25);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon22);
        }
    }

    void Upgrade26()
    {
        damageReductionLevel++;
        CheckIfRoomForPassives();
        damageReduction += 10;
        
        if (damageReductionLevel == 5)
        {
            Upgrade.Remove(Upgrade26);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text26);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon23);
        }
    }

    void Upgrade27()
    {
        healRegenLevel++;
        CheckIfRoomForPassives();
        gameObject.GetComponent<PlayerHealth>().healRegen += 0.5f;

        if (healRegenLevel == 5)
        {
            Upgrade.Remove(Upgrade27);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(gameManager.GetComponent<UpgradesTextList>().text27);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(gameManager.GetComponent<UpgradesTextList>().icon24);
        }
    }
















    // Augments 
    void Augment0()
    {
        weaponsAugmented++;
        Debug.Log("Test augment");
    }

    void Augment1()
    {
        weaponsAugmented++;
        lightningSpawner.GetComponent<LightningAttackSpawner>().augmented = true;
    }

    void Augment2()
    {
        weaponsAugmented++;
        rocketSpawner.GetComponent<RocketAttackSpawner>().augmented = true;
    }

    void Augment3()
    {
        weaponsAugmented++;
        swordSpawner.GetComponent<SwordAttackSpawner>().augmented = true;
    }

    void Augment4()
    {
        weaponsAugmented++;
        droneSpawner.GetComponent<RotatingDroneAttackSpawner>().augmented = true;
        droneSpawner.GetComponent<RotatingDroneAttackSpawner>().pivot2.SetActive(true);
    }

    void Augment5()
    {
        weaponsAugmented++;
        laserSpawner.GetComponent<LaserAttackSpawner>().augmented = true;
    }

    void Augment6()
    {
        weaponsAugmented++;
        grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().augmented = true;
    }

    void Augment7()
    {
        weaponsAugmented++;
        spiralSpawner.GetComponent<SpiralAttackSpawner>().augmented = true;
    }

    void Augment8()
    {
        weaponsAugmented++;
        meteorSpawner.GetComponent<MeteorAttackSpawner>().augmented = true;
    }

    void Augment9()
    {
        weaponsAugmented++;
        splitSpawner.GetComponent<SplitAttackSpawner>().projectilesNumber = 36;
        splitSpawner.GetComponent<SplitAttackSpawner>().timeBetweenShots = 0.02f;
    }

    void Augment10()
    {
        weaponsAugmented++;
        plasmaSpawner.GetComponent<PlasmaAttackSpawner>().augmented = true;
    }

    void Augment11()
    {
        weaponsAugmented++;
        fieldSpawner.GetComponent<FieldAttackSpawner>().augmented = true;
        fieldSpawner.GetComponent<FieldAttackSpawner>().shrink = 0.06f;
    }

    void Augment12()
    {
        weaponsAugmented++;
        bouncySpawner.GetComponent<BouncyAttackSpawner>().augmented = true;
    }

    void Augment13()
    {
        weaponsAugmented++;
        raySpawner.GetComponent<RayAttackSpawner>().augmented = true;
        raySpawner.transform.GetChild(1).gameObject.SetActive(true);
    }









    // tools

    void CheckIfRoomForWeapons()
    {
        weaponsEquipped++;
        if (weaponsEquipped >= 5)
        {
            //Remove(piercingSpikesLevel, Upgrade3, gameManager.GetComponent<UpgradesTextList>().text3);
            Remove(lightningLevel, Upgrade4, gameManager.GetComponent<UpgradesTextList>().text4, gameManager.GetComponent<UpgradesTextList>().icon3);
            Remove(rocketLevel, Upgrade5, gameManager.GetComponent<UpgradesTextList>().text5, gameManager.GetComponent<UpgradesTextList>().icon4);
            Remove(swordLevel, Upgrade6, gameManager.GetComponent<UpgradesTextList>().text6, gameManager.GetComponent<UpgradesTextList>().icon5);
            Remove(droneLevel, Upgrade7, gameManager.GetComponent<UpgradesTextList>().text7, gameManager.GetComponent<UpgradesTextList>().icon6);
            Remove(laserLevel, Upgrade8, gameManager.GetComponent<UpgradesTextList>().text8, gameManager.GetComponent<UpgradesTextList>().icon7);
            Remove(grenadeLevel, Upgrade9, gameManager.GetComponent<UpgradesTextList>().text9, gameManager.GetComponent<UpgradesTextList>().icon8);
            Remove(spiralLevel, Upgrade10, gameManager.GetComponent<UpgradesTextList>().text10, gameManager.GetComponent<UpgradesTextList>().icon9);
            Remove(meteorLevel, Upgrade11, gameManager.GetComponent<UpgradesTextList>().text11, gameManager.GetComponent<UpgradesTextList>().icon10);
            Remove(splitLevel, Upgrade12, gameManager.GetComponent<UpgradesTextList>().text12, gameManager.GetComponent<UpgradesTextList>().icon11);
            Remove(plasmaLevel, Upgrade13, gameManager.GetComponent<UpgradesTextList>().text13, gameManager.GetComponent<UpgradesTextList>().icon12);
            Remove(fieldLevel, Upgrade14, gameManager.GetComponent<UpgradesTextList>().text14, gameManager.GetComponent<UpgradesTextList>().icon13);
            //Remove(bouncyLevel, Upgrade15, gameManager.GetComponent<UpgradesTextList>().text15);
        }
    }

    void CheckIfRoomForPassives()
    {
        passivesEquiped++;
        if (passivesEquiped >= 5)
        {
            Remove(projectileNumberLevel, Upgrade0, gameManager.GetComponent<UpgradesTextList>().text0, gameManager.GetComponent<UpgradesTextList>().icon0);
            Remove(healthUpgradeLevel, Upgrade1, gameManager.GetComponent<UpgradesTextList>().text1, gameManager.GetComponent<UpgradesTextList>().icon1);
            Remove(movementSpeedLevel, Upgrade2, gameManager.GetComponent<UpgradesTextList>().text2, gameManager.GetComponent<UpgradesTextList>().icon2);
            Remove(cooldownLevel, Upgrade19, gameManager.GetComponent<UpgradesTextList>().text19, gameManager.GetComponent<UpgradesTextList>().icon17);
            Remove(projectileSpeedLevel, Upgrade20, gameManager.GetComponent<UpgradesTextList>().text20, gameManager.GetComponent<UpgradesTextList>().icon18);
            Remove(attackLevel, Upgrade21, gameManager.GetComponent<UpgradesTextList>().text21, gameManager.GetComponent<UpgradesTextList>().icon19);
            //Remove(knockbackLevel, Upgrade22, gameManager.GetComponent<UpgradesTextList>().text22, gameManager.GetComponent<UpgradesTextList>().icon20);
            Remove(projectileSizeLevel, Upgrade23, gameManager.GetComponent<UpgradesTextList>().text23, gameManager.GetComponent<UpgradesTextList>().icon20);
            Remove(upgradeXPlevel, Upgrade24, gameManager.GetComponent<UpgradesTextList>().text24, gameManager.GetComponent<UpgradesTextList>().icon21);
            Remove(pickupRangeLevel, Upgrade25, gameManager.GetComponent<UpgradesTextList>().text25, gameManager.GetComponent<UpgradesTextList>().icon22);
            Remove(damageReductionLevel, Upgrade26, gameManager.GetComponent<UpgradesTextList>().text26, gameManager.GetComponent<UpgradesTextList>().icon23);
            Remove(healRegenLevel, Upgrade27, gameManager.GetComponent<UpgradesTextList>().text27, gameManager.GetComponent<UpgradesTextList>().icon24);
        }
    }

    void RemoveActiveWeapons()
    {
        Remove(rayLevel, Upgrade16, gameManager.GetComponent<UpgradesTextList>().text16, gameManager.GetComponent<UpgradesTextList>().icon14);
        Remove(minigunLevel, Upgrade17, gameManager.GetComponent<UpgradesTextList>().text17, gameManager.GetComponent<UpgradesTextList>().icon15);
        Remove(activeRocketLevel, Upgrade18, gameManager.GetComponent<UpgradesTextList>().text18, gameManager.GetComponent<UpgradesTextList>().icon16);
    }



    // Fillers
    public void FillerUpgrade1()
    {
        if (gameObject.GetComponent<PlayerHealth>().currentHealth + (30f / 100f) * gameObject.GetComponent<PlayerHealth>().maxHealth > gameObject.GetComponent<PlayerHealth>().maxHealth)
        {
            gameObject.GetComponent<PlayerHealth>().currentHealth = gameObject.GetComponent<PlayerHealth>().maxHealth;
        }
        else
        {
            gameObject.GetComponent<PlayerHealth>().currentHealth += (30f / 100f) * gameObject.GetComponent<PlayerHealth>().maxHealth;
        }
    }

    public void FillerUpgrade2()
    {
        gameManager.GetComponent<Interface>().upgradePoints += 10;
    }

    public void FillerUpgrade3()
    {
        Debug.Log("teleport to nearest Dome Market");
    }

    public void AugmentFiler()
    {
        gameManager.GetComponent<Interface>().upgradePoints += 200;
    }

    void Remove(int weaponLevel, UpgradeMethod upgrade, string[] text, Sprite icon)
    {
        if (weaponLevel == 0)
        {
            Upgrade.Remove(upgrade);
            gameManager.GetComponent<UpgradesTextList>().UpgradeText.Remove(text);
            gameManager.GetComponent<UpgradesTextList>().icons.Remove(icon);
        }
    }


    void IncreaseAttack(float value)
    {
        piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackDamage += value / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackDamage;
        lightningSpawner.GetComponent<LightningAttackSpawner>().attackDamage += value / 100 * lightningSpawner.GetComponent<LightningAttackSpawner>().attackDamage;
        rocketSpawner.GetComponent<RocketAttackSpawner>().attackDamage += value / 100 * rocketSpawner.GetComponent<RocketAttackSpawner>().attackDamage;
        swordSpawner.GetComponent<SwordAttackSpawner>().attackDamage += value / 100 * swordSpawner.GetComponent<SwordAttackSpawner>().attackDamage;
        droneSpawner.GetComponent<RotatingDroneAttackSpawner>().attackDamage += value / 100 * droneSpawner.GetComponent<RotatingDroneAttackSpawner>().attackDamage;
        laserSpawner.GetComponent<LaserAttackSpawner>().attackDamage += value / 100 * laserSpawner.GetComponent<LaserAttackSpawner>().attackDamage;
        grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().attackDamage += value / 100 * grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().attackDamage;
        spiralSpawner.GetComponent<SpiralAttackSpawner>().attackDamage += value / 100 * spiralSpawner.GetComponent<SpiralAttackSpawner>().attackDamage;
        meteorSpawner.GetComponent<MeteorAttackSpawner>().attackDamage += value / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().attackDamage;
        splitSpawner.GetComponent<SplitAttackSpawner>().attackDamage += value / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().attackDamage;
        plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackDamage += value / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackDamage;
        fieldSpawner.GetComponent<FieldAttackSpawner>().attackDamage += value / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().attackDamage;
        bouncySpawner.GetComponent<BouncyAttackSpawner>().attackDamage += value / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().attackDamage;
        raySpawner.GetComponentInChildren<RayAttackEvent>().attackDamage += value / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().attackDamage;
        minigunSpawner.GetComponent<MinigunAttackSpawner>().attackDamage += value / 100 * minigunSpawner.GetComponent<MinigunAttackSpawner>().attackDamage;
        activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().attackDamage += value / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().attackDamage;
    }

    void DecreaseCooldown(float value)
    {
        piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackSpeed -= value / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().attackSpeed;
        lightningSpawner.GetComponent<LightningAttackSpawner>().attackSpeed -= value / 100 * lightningSpawner.GetComponent<LightningAttackSpawner>().attackSpeed;
        rocketSpawner.GetComponent<RocketAttackSpawner>().attackSpeed -= value / 100 * rocketSpawner.GetComponent<RocketAttackSpawner>().attackSpeed;
        swordSpawner.GetComponent<SwordAttackSpawner>().attackSpeed -= value / 100 * swordSpawner.GetComponent<SwordAttackSpawner>().attackSpeed;
        droneSpawner.GetComponent<RotatingDroneAttackSpawner>().attackSpeed -= value / 100 * droneSpawner.GetComponent<RotatingDroneAttackSpawner>().attackSpeed;
        laserSpawner.GetComponent<LaserAttackSpawner>().attackSpeed -= value / 100 * laserSpawner.GetComponent<LaserAttackSpawner>().attackSpeed;
        grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().attackSpeed -= value / 100 * grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().attackSpeed;
        spiralSpawner.GetComponent<SpiralAttackSpawner>().attackSpeed -= value / 100 * spiralSpawner.GetComponent<SpiralAttackSpawner>().attackSpeed;
        meteorSpawner.GetComponent<MeteorAttackSpawner>().attackSpeed -= value / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().attackSpeed;
        splitSpawner.GetComponent<SplitAttackSpawner>().attackSpeed -= value / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().attackSpeed;
        plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackSpeed -= value / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().attackSpeed;
        fieldSpawner.GetComponent<FieldAttackSpawner>().attackSpeed -= value / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().attackSpeed;
        bouncySpawner.GetComponent<BouncyAttackSpawner>().attackSpeed -= value / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().attackSpeed;
        raySpawner.GetComponentInChildren<RayAttackEvent>().attackSpeed -= value / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().attackSpeed;
        minigunSpawner.GetComponent<MinigunAttackSpawner>().attackSpeed -= value / 100 * minigunSpawner.GetComponent<MinigunAttackSpawner>().attackSpeed;
        activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().cooldownDuration -= value / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().cooldownDuration;
    }

    void IncreaseProjectileSpeed(float value)
    {
        piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().projectileSpeed += value / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().projectileSpeed;
        lightningSpawner.GetComponent<LightningAttackSpawner>().projectileSpeed += value / 100 * lightningSpawner.GetComponent<LightningAttackSpawner>().projectileSpeed;
        rocketSpawner.GetComponent<RocketAttackSpawner>().projectileSpeed += value / 100 * rocketSpawner.GetComponent<RocketAttackSpawner>().projectileSpeed;
        swordSpawner.GetComponent<SwordAttackSpawner>().projectileSpeed += value / 100 * swordSpawner.GetComponent<SwordAttackSpawner>().projectileSpeed;
        droneSpawner.GetComponent<RotatingDroneAttackSpawner>().projectileSpeed += value / 100 * droneSpawner.GetComponent<RotatingDroneAttackSpawner>().projectileSpeed;
        laserSpawner.GetComponent<LaserAttackSpawner>().projectileSpeed += value / 100 * laserSpawner.GetComponent<LaserAttackSpawner>().projectileSpeed;
        grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().projectileSpeed += value / 100 * grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().projectileSpeed;
        spiralSpawner.GetComponent<SpiralAttackSpawner>().projectileSpeed += value / 100 * spiralSpawner.GetComponent<SpiralAttackSpawner>().projectileSpeed;
        meteorSpawner.GetComponent<MeteorAttackSpawner>().projectileSpeed += value / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().projectileSpeed;
        splitSpawner.GetComponent<SplitAttackSpawner>().projectileSpeed += value / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().projectileSpeed;
        plasmaSpawner.GetComponent<PlasmaAttackSpawner>().projectileSpeed += value / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().projectileSpeed;
        fieldSpawner.GetComponent<FieldAttackSpawner>().projectileSpeed += value / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().projectileSpeed;
        bouncySpawner.GetComponent<BouncyAttackSpawner>().projectileSpeed += value / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().projectileSpeed;
        raySpawner.GetComponentInChildren<RayAttackEvent>().projectileSpeed += value / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().projectileSpeed;
        minigunSpawner.GetComponent<MinigunAttackSpawner>().projectileSpeed += value / 100 * minigunSpawner.GetComponent<MinigunAttackSpawner>().projectileSpeed;
        activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().projectileSpeed += value / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().projectileSpeed;
    }

    void IncreaseKnockback(float value)
    {
        piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().knockbackForce += value / 100 * piercingSpikesSpawner.GetComponent<PiercingSpikeAttackSpawner>().knockbackForce;
        lightningSpawner.GetComponent<LightningAttackSpawner>().knockbackForce += value / 100 * lightningSpawner.GetComponent<LightningAttackSpawner>().knockbackForce;
        rocketSpawner.GetComponent<RocketAttackSpawner>().knockbackForce += value / 100 * rocketSpawner.GetComponent<RocketAttackSpawner>().knockbackForce;
        swordSpawner.GetComponent<SwordAttackSpawner>().knockbackForce += value / 100 * swordSpawner.GetComponent<SwordAttackSpawner>().knockbackForce;
        droneSpawner.GetComponent<RotatingDroneAttackSpawner>().knockbackForce += value / 100 * droneSpawner.GetComponent<RotatingDroneAttackSpawner>().knockbackForce;
        laserSpawner.GetComponent<LaserAttackSpawner>().knockbackForce += value / 100 * laserSpawner.GetComponent<LaserAttackSpawner>().knockbackForce;
        grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().knockbackForce += value / 100 * grenadeSpawner.GetComponent<GoopGrenadeAttackSpawner>().knockbackForce;
        spiralSpawner.GetComponent<SpiralAttackSpawner>().knockbackForce += value / 100 * spiralSpawner.GetComponent<SpiralAttackSpawner>().knockbackForce;
        meteorSpawner.GetComponent<MeteorAttackSpawner>().knockbackForce += value / 100 * meteorSpawner.GetComponent<MeteorAttackSpawner>().knockbackForce;
        splitSpawner.GetComponent<SplitAttackSpawner>().knockbackForce += value / 100 * splitSpawner.GetComponent<SplitAttackSpawner>().knockbackForce;
        plasmaSpawner.GetComponent<PlasmaAttackSpawner>().knockbackForce += value / 100 * plasmaSpawner.GetComponent<PlasmaAttackSpawner>().knockbackForce;
        fieldSpawner.GetComponent<FieldAttackSpawner>().knockbackForce += value / 100 * fieldSpawner.GetComponent<FieldAttackSpawner>().knockbackForce;
        bouncySpawner.GetComponent<BouncyAttackSpawner>().knockbackForce += value / 100 * bouncySpawner.GetComponent<BouncyAttackSpawner>().knockbackForce;
        raySpawner.GetComponentInChildren<RayAttackEvent>().knockbackForce += value / 100 * raySpawner.GetComponentInChildren<RayAttackEvent>().knockbackForce;
        minigunSpawner.GetComponent<MinigunAttackSpawner>().knockbackForce += value / 100 * minigunSpawner.GetComponent<MinigunAttackSpawner>().knockbackForce;
        activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().knockbackForce += value / 100 * activeRocketSpawner.GetComponent<ActiveRocketAttackSpawner>().knockbackForce;
    }

    void IncreaseProjectileSize(float value)
    {
        gameManager.GetComponent<AttackStats>().projectileSize += value;
    }

    int SetWeaponsIcon(Sprite icon)
    {
        for (int i = 0; i < weaponsIcons.Length; i++)
        {
            if (weaponsIcons[i].sprite == emptyIcon)
            {
                weaponsIcons[i].sprite = icon;
                return i;
            }
        }
        return 0;
    }
}
