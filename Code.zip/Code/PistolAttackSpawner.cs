using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PistolAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;

    private bool doneAttacking = false;
    public GameObject gameManager;

    void Update()
    {
        //Vector2 direction = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
    }

    private void FixedUpdate()
    {
        if (!doneAttacking)
        {
            StartCoroutine(LaunchProjectile());
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;
        gameManager.GetComponent<FindClosestEnemy>().FindEnemy();

        for (int i = 1; i <= 1 + gameManager.GetComponent<AttackStats>().numberOfProjectiles ; i++)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().closestEnemy != null)
            {
                Vector2 direction = gameManager.GetComponent<FindClosestEnemy>().closestEnemy.transform.position - transform.position;
                float angle = Mathf.Atan2(direction.y + 0.5f, direction.x) * Mathf.Rad2Deg;
                Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
                transform.rotation = rotation;

                GameObject instance = Instantiate(projectile, transform.position, transform.rotation);
                instance.GetComponent<PistolAttackEvent>().attackDamage = attackDamage;
                instance.GetComponent<PistolAttackEvent>().knockbackForce = knockbackForce;
                instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
                instance.GetComponent<Rigidbody2D>().velocity = instance.transform.right * projectileSpeed;
                yield return new WaitForSeconds(0.15f);
            }
        }

        yield return new WaitForSeconds(attackSpeed);
        doneAttacking = false;
    }
}
