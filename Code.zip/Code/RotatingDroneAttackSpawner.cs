using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotatingDroneAttackSpawner : MonoBehaviour
{
    public float spinSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float attackSpeed = 0;
    public float projectileSpeed = 0;

    private bool increaseScale = false;
    public bool augmented = false;

    private GameObject[] drones;
    public GameObject gameManager;

    public GameObject pivot1;
    public GameObject pivot2;

    private float previousSize;

    void Start()
    {
        previousSize = gameManager.GetComponent<AttackStats>().projectileSize;

        drones = new GameObject[16];
        for (int i = 0; i < 8; i++)
        {
            drones[i] = pivot1.transform.GetChild(i).gameObject;
            drones[i + 8] = pivot2.transform.GetChild(i).gameObject;
        }

        InvokeRepeating("UpdateStats", 0, 3);
    }

    private void FixedUpdate()
    {
        if (augmented)
        {
            if (increaseScale)
            {
                if (pivot1.transform.localScale.x < 1.5f)
                {
                    pivot1.transform.localScale += new Vector3(0.5f, 0.5f) * Time.deltaTime;
                    pivot2.transform.localScale -= new Vector3(0.5f, 0.5f) * Time.deltaTime;
                }
                else
                {
                    increaseScale = false;
                }
            }
            else
            {
                if (pivot1.transform.localScale.x > 1)
                {
                    pivot1.transform.localScale -= new Vector3(0.5f, 0.5f) * Time.deltaTime;
                    pivot2.transform.localScale += new Vector3(0.5f, 0.5f) * Time.deltaTime;
                }
                else
                {
                    increaseScale = true;
                }
            }
            for (int i = 0; i < 8; i++)
            {
                drones[i].transform.localScale = new Vector3(1 / pivot1.transform.localScale.x * 9, 1 / pivot1.transform.localScale.y * 9);
            }
            for (int i = 8; i < 16; i++)
            {
                drones[i].transform.localScale = new Vector3(1 / pivot2.transform.localScale.x * 9, 1 / pivot2.transform.localScale.y * 9);
            }
        }

        if (gameManager.GetComponent<AttackStats>().projectileSize != previousSize)
        {
            transform.localScale += new Vector3((gameManager.GetComponent<AttackStats>().projectileSize - previousSize) / 100 * transform.localScale.x, (gameManager.GetComponent<AttackStats>().projectileSize - previousSize) / 100 * transform.localScale.y, 0);
            previousSize = gameManager.GetComponent<AttackStats>().projectileSize;
        }
    }

    void UpdateStats()
    {
        pivot1.GetComponent<RotatingDronePivot>().spinSpeed = spinSpeed;
        pivot2.GetComponent<RotatingDronePivot>().spinSpeed = -spinSpeed;

        for (int j = 0; j < drones.Length; j++)
        {
            drones[j].GetComponent<RotatingDroneAttaclEvemt>().attackDamage = attackDamage;
            drones[j].GetComponent<RotatingDroneAttaclEvemt>().knockbackForce = knockbackForce;
        }
    }
}
