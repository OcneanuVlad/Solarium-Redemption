using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public bool augmented;
    public int maxTimesHit;
    public int numberOfProjectiles;

    private bool doneAttacking = false;
    public GameObject gameManager;


    private void FixedUpdate()
    {
        if (!doneAttacking)
        {
            StartCoroutine(LaunchProjectile());
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;

        for (int i = 1; i <= numberOfProjectiles + gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            SpawnProjectile(45);
            SpawnProjectile(-45);
            SpawnProjectile(135);
            SpawnProjectile(-135);
            yield return new WaitForSeconds(0.2f);
        }

        yield return new WaitForSeconds(attackSpeed);
        doneAttacking = false;
    }

    void SpawnProjectile(float rotation)
    {
        GameObject instance = Instantiate(projectile, transform.position, Quaternion.Euler(0, 0, rotation));
        instance.GetComponent<LaserAttackEvent>().attackDamage = attackDamage;
        instance.GetComponent<LaserAttackEvent>().knockbackForce = knockbackForce;
        instance.GetComponent<LaserAttackEvent>().augmented = augmented;
        instance.GetComponent<LaserAttackEvent>().maxTimeHit = maxTimesHit;
        instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
        instance.GetComponent<Rigidbody2D>().velocity = instance.transform.right * projectileSpeed;
    }
}

