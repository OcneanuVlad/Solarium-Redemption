using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyCounter : MonoBehaviour
{
    [HideInInspector] public int enemyCounter = 0;
    public Text enemyCounterText;
    // Start is called before the first frame update
    void Start()
    {
        enemyCounterText = GameObject.Find("EnemyCounter").GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        enemyCounterText.text = enemyCounter.ToString();
    }
}
