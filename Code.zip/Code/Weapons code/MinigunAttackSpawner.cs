using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinigunAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public float timeBetweenBullets;
    public int projectileNumber;

    private bool doneAttacking = false;
    public GameObject gameManager;

    public GameObject[] spawnPoints;

    void Update()
    {
        Vector2 direction = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        transform.rotation = rotation;
    }

    private void FixedUpdate()
    {
        if (!doneAttacking)
        {
            StartCoroutine(LaunchProjectile());
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;

        int i;
        for (i = 1; i <= projectileNumber + 2 * gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            GameObject instance = Instantiate(projectile, spawnPoints[Random.Range(0, 10)].transform.position, transform.rotation);
            instance.GetComponent<MinigunAttackEvent>().attackDamage = attackDamage;
            instance.GetComponent<MinigunAttackEvent>().knockbackForce = knockbackForce;
            instance.GetComponent<Rigidbody2D>().velocity = instance.transform.right * (projectileSpeed + gameManager.GetComponent<AttackStats>().projectileSpeed * projectileSpeed);
            instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
            yield return new WaitForSeconds(timeBetweenBullets);
        }

        if (attackSpeed - gameManager.GetComponent<AttackStats>().attackSpeed * attackSpeed - (i * 0.15f) > 0.15f)
        {
            yield return new WaitForSeconds(attackSpeed - gameManager.GetComponent<AttackStats>().attackSpeed * attackSpeed - (i * timeBetweenBullets));
        }
        else
        {
            yield return new WaitForSeconds(timeBetweenBullets);
        }
        doneAttacking = false;
    }
}

