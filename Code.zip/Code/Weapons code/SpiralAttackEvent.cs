using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpiralAttackEvent : MonoBehaviour
{
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float projectileSpeed;
    [HideInInspector] public float rotationSpeed;
    private float rotationSpeedBrake = 10;
    private float projectileSpeedBrake = 4;

    [HideInInspector] public bool augmented;
    public GameObject explosion;

    private new Rigidbody2D rigidbody;
    public GameObject gameManager;
    [HideInInspector] public GameObject player;

    private Vector2 positionInCamera;

    private void Start()
    { 
        rigidbody = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        positionInCamera = Camera.main.WorldToViewportPoint(transform.position);
        if (positionInCamera.x < -0.1f || positionInCamera.x > 1.1f || positionInCamera.y < -0.1f || positionInCamera.y > 1.1f)
        {
            Destroy(gameObject);
        }

        rigidbody.velocity = (Vector2)transform.right * projectileSpeed;
        if (augmented)
        {
            rigidbody.velocity += player.GetComponent<PlayerMovement>().playerRigidbody.velocity;
        }
        transform.Rotate(0, 0, rotationSpeed);
        rotationSpeed -= (rotationSpeed / rotationSpeedBrake) * Time.deltaTime;
        if (projectileSpeed < 35)
        {
            projectileSpeed += (projectileSpeed / projectileSpeedBrake) * Time.deltaTime;
        }
        rotationSpeedBrake += (rotationSpeedBrake / 1000) * Time.deltaTime;
        projectileSpeedBrake -= (projectileSpeedBrake / 3000) * Time.deltaTime;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {

            if (augmented)
            {
                GameObject instance = Instantiate(explosion, transform.position, transform.rotation);
                if (instance != null)
                {
                    instance.GetComponent<ScytheExplosion>().attackDamage = attackDamage;
                    instance.transform.localScale = new Vector2(3.5f, 3.5f);
                }
            }

            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage + gameManager.GetComponent<AttackStats>().attackDamage * attackDamage;
            collision.gameObject.GetComponent<EnemyGeneral>().projectileDirection = Vector2.zero;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            { 
                collision.gameObject.GetComponent<EnemyGeneral>().stun = true;
            }
        }
    }
}
