using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BouncyAttackEvent : MonoBehaviour
{
    private Vector3 positionInCamera;
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;
    [HideInInspector] public int maxEnemiesHit;
    public GameObject bouncyDebuff;
    [HideInInspector] public bool augmented;

    private int enemiesHit = 0;

    public GameObject gameManager;


    void Update()
    {
        positionInCamera = Camera.main.WorldToViewportPoint(transform.position);
        if (positionInCamera.x < -0.2f || positionInCamera.x > 1.2f || positionInCamera.y < -0.2 || positionInCamera.y > 1.2)
        {
            Destroy(gameObject);
        }
    }

    private void FixedUpdate()
    {
        transform.Rotate(0, 0, 400 * Time.deltaTime);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            if (augmented)
            {
                GameObject instance = Instantiate(bouncyDebuff, new Vector3(collision.gameObject.transform.position.x, collision.gameObject.transform.position.y + 0.5f), transform.rotation);
                instance.transform.SetParent(collision.gameObject.transform);
                instance.GetComponent<BouncyDebuff>().attackDamage = attackDamage / 2;
            }
            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage + gameManager.GetComponent<AttackStats>().attackDamage * attackDamage;
            collision.gameObject.GetComponent<EnemyGeneral>().projectileDirection = transform.position;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            {
                collision.gameObject.GetComponent<EnemyGeneral>().knockbackForce = knockbackForce + gameManager.GetComponent<AttackStats>().knockbackForce * knockbackForce;
                collision.gameObject.GetComponent<EnemyGeneral>().stun = true;
            }

            enemiesHit++;
            if (enemiesHit >= maxEnemiesHit)
            {
                Destroy(gameObject);
            }
        }
    }
}
