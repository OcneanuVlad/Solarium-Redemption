using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwordAttackEvent : MonoBehaviour
{
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;

    [HideInInspector] public bool isFlyingSword = false;


    private void FixedUpdate()
    {
        if (isFlyingSword)
        {
            transform.Rotate(0, 0, -800 * Time.deltaTime);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            {
                collision.gameObject.GetComponent<EnemyGeneral>().knockbackForce = knockbackForce;
                collision.gameObject.GetComponent<EnemyGeneral>().stun = true;
            }
        }
    }
}
