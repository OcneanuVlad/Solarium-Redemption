using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RocketAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public bool augmented = false;
    public float scale = 1.4f;
    public int numberOfProjectiles = 2;

    private bool doneAttacking;
    public GameObject gameManager;
    private GameObject enemyToDamage;

    private void Start()
    {
        doneAttacking = false;
    }

    private void FixedUpdate()
    {
        if (!doneAttacking)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
            {
                StartCoroutine(LaunchProjectile());
            }
            else
            {
                gameManager.GetComponent<FindClosestEnemy>().FindEnemy();
            }
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;
        gameManager.GetComponent<FindClosestEnemy>().FindEnemy();

        for (int i = 1; i <= numberOfProjectiles + gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
            {
                int randomEnemy = Random.Range(0, gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length);
                if (gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy] != null)
                {
                    enemyToDamage = gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy].gameObject;
                    Vector2 direction = enemyToDamage.transform.position - transform.position;
                    float angle = Mathf.Atan2(direction.y + 0.5f, direction.x) * Mathf.Rad2Deg;
                    Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
                    transform.rotation = rotation;

                    GameObject instance = Instantiate(projectile, transform.position, transform.rotation);
                    instance.GetComponent<RocketAttackEvent>().destination = enemyToDamage;
                    instance.GetComponent<RocketAttackEvent>().augmented = augmented;
                    instance.GetComponent<RocketAttackEvent>().attackDamage = attackDamage;
                    instance.GetComponent<RocketAttackEvent>().knockbackForce = knockbackForce;
                    instance.GetComponent<RocketAttackEvent>().projectileSpeed = projectileSpeed;
                    instance.transform.localScale = new Vector3(scale, scale);
                    instance.transform.localScale += gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale;
                    yield return new WaitForSeconds(0.45f);
                }
            }
        }

        yield return new WaitForSeconds(attackSpeed);
        doneAttacking = false;
    }
}

