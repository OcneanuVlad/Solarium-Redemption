using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpiralAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public float rotationSpeed;
    public bool augmented = false;
    public float scale = 1;
    public int maxEnemiesHit;

    public GameObject player;

    private bool doneAttacking = false;
    public GameObject gameManager;


    private void FixedUpdate()
    {
        if (!doneAttacking)
        {
            StartCoroutine(LaunchProjectile());
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;
        int i;

        for (i = 1; i <= 1 + gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            GameObject instance = Instantiate(projectile, transform.position, Quaternion.Euler(0, 0, Random.Range(0, 360)));
            instance.GetComponent<SpiralAttackEvent>().attackDamage = attackDamage;
            instance.GetComponent<SpiralAttackEvent>().projectileSpeed = projectileSpeed;
            instance.GetComponent<SpiralAttackEvent>().rotationSpeed = rotationSpeed;
            instance.GetComponent<SpiralAttackEvent>().player = player;
            instance.GetComponent<SpiralAttackEvent>().augmented = augmented;
            instance.transform.localScale = new Vector3(scale, scale, 1);
            instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
            yield return new WaitForSeconds(0.45f);
        }

        yield return new WaitForSeconds(attackSpeed);
        doneAttacking = false;
    }

}

