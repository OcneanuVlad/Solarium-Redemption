using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RayAttackEvent : MonoBehaviour
{
    private bool givingDamage = false;
    public float attackDamage;
    public float projectileSpeed;
    public float attackSpeed;
    public float knockbackForce;
    private List<GameObject> enemiesInPuddle;

    public Image coolOffImage;
    public GameObject player;
    private float playerMovementSpeed;
    private Animator animator;
    private bool closing = false;

    private float coolOff;
    public float coolOffMax;
    public float coolOffSpeed;
    private float windUp;
    private bool overHeated;

    private float previousSize;

    public GameObject gameManager;

    private void Start()
    {
        previousSize = gameManager.GetComponent<AttackStats>().projectileSize;

        animator = GetComponent<Animator>();
        playerMovementSpeed = player.GetComponent<PlayerMovement>().movementSpeed;
        windUp = 0;
        coolOff = 0;
        enemiesInPuddle = new List<GameObject>();
    }

    private void Update()
    {
        if (enemiesInPuddle.Count > 0)
        {
            if (!givingDamage)
            {
                for (int i = 0; i < enemiesInPuddle.Count; i++)
                {
                    StartCoroutine(DamageEnemies(enemiesInPuddle[i]));
                }
            }
        }

        if (coolOff < coolOffMax)
        {
            if (Input.GetKey(KeyCode.Mouse0) && !overHeated && windUp > 0.5f)
            {
                coolOff += Time.deltaTime;
            }
            else
            {
                if (coolOff > 0)
                    if (!overHeated)
                    {
                        coolOff -= coolOffSpeed * Time.deltaTime;
                    }
                    else
                    {
                        coolOff -= coolOffSpeed * (0.5f * Time.deltaTime);
                    }
                else
                {
                    overHeated = false;
                }
            }
        }
        else
        {
            overHeated = true;
            if (coolOff > 0)
            {
                if (!overHeated)
                {
                    coolOff -= coolOffSpeed * Time.deltaTime;
                }
                else
                {
                    coolOff -= coolOffSpeed * (0.5f * Time.deltaTime);
                }
            }
            else
            {
                overHeated = false;
            }
        }

        if (Input.GetKey(KeyCode.Mouse0))
        {
            if (!overHeated && !gameManager.GetComponent<Interface>().isInUpgradeBox)
            {
                player.GetComponent<PlayerMovement>().movementSpeed = playerMovementSpeed / 2.5f;
                playerMovementSpeed = player.GetComponent<PlayerMovement>().movementSpeed * 2.5f;
                StopCoroutine(Close());
                animator.SetBool("Close", false);
                if (windUp < 0.5f)
                {
                    closing = false;
                    windUp += Time.deltaTime;
                    GetComponent<SpriteRenderer>().enabled = true;
                    animator.SetBool("Start", true);
                }
                else
                {
                    animator.SetBool("Start", false);
                    GetComponent<Collider2D>().enabled = true;
                }
            }
            else
            {
                if (windUp > 0)
                {
                    windUp = 0;
                }
                if (!closing)
                {
                    StartCoroutine(Close());
                }
                GetComponent<Collider2D>().enabled = false;
                player.GetComponent<PlayerMovement>().movementSpeed = playerMovementSpeed;
                playerMovementSpeed = player.GetComponent<PlayerMovement>().movementSpeed;
            }
        }
        else
        {
            if (windUp > 0)
            {
                windUp = 0;
            }
            if (!closing)
            {
                StartCoroutine(Close());
            }
            GetComponent<Collider2D>().enabled = false;
            player.GetComponent<PlayerMovement>().movementSpeed = playerMovementSpeed;
            playerMovementSpeed = player.GetComponent<PlayerMovement>().movementSpeed;
        }

        coolOffImage.fillAmount = coolOff / 5f;
    }

    private void FixedUpdate()
    {
        if (gameManager.GetComponent<AttackStats>().projectileSize != previousSize)
        {
            transform.localScale += new Vector3((gameManager.GetComponent<AttackStats>().projectileSize - previousSize) / 100 * transform.localScale.x, (gameManager.GetComponent<AttackStats>().projectileSize - previousSize) / 100 * transform.localScale.y, 0);
            previousSize = gameManager.GetComponent<AttackStats>().projectileSize;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            enemiesInPuddle.Add(collision.gameObject);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            enemiesInPuddle.Remove(collision.gameObject);
        }
    }

    IEnumerator DamageEnemies(GameObject enemy)
    {
        givingDamage = true;
        enemy.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage + gameManager.GetComponent<AttackStats>().attackDamage * attackDamage;
        if (enemy.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
        {
            enemy.gameObject.GetComponent<EnemyGeneral>().die = true;
        }
        else
        {
            enemy.gameObject.GetComponent<EnemyGeneral>().stun = true;
        }
        yield return new WaitForSecondsRealtime(0.1f);
        givingDamage = false;
    }

    IEnumerator Close()
    {
        closing = true;
        animator.SetBool("Start", false);
        animator.SetBool("Close", true);
        yield return new WaitForSecondsRealtime(0.5f);
        GetComponent<SpriteRenderer>().enabled = false;
        animator.SetBool("Close", false);
    }
}
