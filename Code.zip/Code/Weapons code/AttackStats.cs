using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackStats : MonoBehaviour
{
    public int numberOfProjectiles = 0;
    public float attackDamage = 0;
    public float projectileSpeed = 0;
    public float attackSpeed = 0;
    public float knockbackForce = 0;
    public float projectileSize = 0;
}
