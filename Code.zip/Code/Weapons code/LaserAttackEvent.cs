using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserAttackEvent : MonoBehaviour
{
    private Vector3 positionInCamera;
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;
    [HideInInspector] public bool augmented;
    [HideInInspector] public int maxTimeHit = 0;
    private int timesHit;
    private bool waitX;
    private bool waitY;

    public GameObject gameManager;

    void Update()
    {
        positionInCamera = Camera.main.WorldToViewportPoint(transform.position);
        if (positionInCamera.x < -0.2f || positionInCamera.x > 1.2f || positionInCamera.y < -0.2 || positionInCamera.y > 1.2)
        {
            Destroy(gameObject);
        }


    }

    private void FixedUpdate()
    {
        if (augmented)
        {
            if ((Camera.main.WorldToViewportPoint(transform.position).x >= 1 || Camera.main.WorldToScreenPoint(transform.position).x <= 0) && !waitX)
            {
                GetComponent<Rigidbody2D>().velocity = new Vector3(GetComponent<Rigidbody2D>().velocity.x * -1, GetComponent<Rigidbody2D>().velocity.y);
                timesHit++;
                if (timesHit >= maxTimeHit)
                {
                    Destroy(gameObject);
                }
                transform.Rotate(0, 0, 90);
                StartCoroutine(WaitX());
            }

            if ((Camera.main.WorldToViewportPoint(transform.position).y >= 1 || Camera.main.WorldToScreenPoint(transform.position).y <= 0) && !waitY)
            {
                GetComponent<Rigidbody2D>().velocity = new Vector3(GetComponent<Rigidbody2D>().velocity.x, GetComponent<Rigidbody2D>().velocity.y * -1);
                timesHit++;
                if (timesHit >= maxTimeHit)
                {
                    Destroy(gameObject);
                }
                transform.Rotate(0, 0, 90);
                StartCoroutine(WaitY());
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage + gameManager.GetComponent<AttackStats>().attackDamage * attackDamage;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            {
                collision.gameObject.GetComponent<EnemyGeneral>().knockbackForce = knockbackForce + gameManager.GetComponent<AttackStats>().knockbackForce * knockbackForce;
                collision.gameObject.GetComponent<EnemyGeneral>().stun = true;
            }
        }
    }

    IEnumerator WaitX()
    {
        waitX = true;
        yield return new WaitForSeconds(0.05f);
        waitX = false;
    }

    IEnumerator WaitY()
    {
        waitY = true;
        yield return new WaitForSeconds(0.05f);
        waitY = false;
    }
}
