using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlyingSwordAttackEvent : MonoBehaviour
{
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;
    [HideInInspector] public float projectileSpeed;
    private bool turned = false;
    private bool secondTurn = false;
    private float initialTurn;

    [HideInInspector] public GameObject turningPoint;
    [HideInInspector] public GameObject player;
    private new Rigidbody2D rigidbody;

    private void Start()
    {
        StartCoroutine(WaitBeforeTurn());
        StartCoroutine(ForceDestroy());

        initialTurn = transform.eulerAngles.z;
        rigidbody = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        rigidbody.velocity = transform.right * projectileSpeed;

        if (turned)
        {
            Vector2 direction = turningPoint.transform.position - transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            transform.rotation = Quaternion.Slerp(transform.rotation, rotation, 0.1f);
        }

        if (Mathf.Abs(initialTurn - transform.eulerAngles.z) > 150 && Mathf.Abs(initialTurn - transform.eulerAngles.z) < 230)
        {
            turned = false;
            secondTurn = true;
        }

        if (secondTurn)
        {
            Vector2 direction = player.transform.position - transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            transform.rotation = Quaternion.Slerp(transform.rotation, rotation, 0.1f);
        }

        if (Vector2.Distance(transform.position, player.transform.position) < 1 && secondTurn)
        {
            Destroy(gameObject);
        }
    }

    IEnumerator WaitBeforeTurn()
    {
        yield return new WaitForSecondsRealtime(0.25f);
        turned = true;
    }

    IEnumerator ForceDestroy()
    {
        yield return new WaitForSecondsRealtime(8);
        Destroy(gameObject);
    }
}