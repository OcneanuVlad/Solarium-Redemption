using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActiveRocketAttackEvent : MonoBehaviour
{
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;
    [HideInInspector] public float projectileSpeed;
    [HideInInspector] public Vector3 destination1;
    [HideInInspector] public Vector3 destination2;
    private bool launched = false;

    public GameObject gameManager;

    private void Update()
    {
        if (!launched)
        {
            Vector2 direction = destination2 - transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            transform.rotation = Quaternion.Slerp(transform.rotation, rotation, 1);
        }
    }

    private void FixedUpdate()
    {
        if (Vector2.Distance(transform.position, destination1) < 0.3f)
        {
            GetComponent<Rigidbody2D>().velocity = ((Vector2)destination2 - (Vector2)transform.position).normalized * projectileSpeed;
            launched = true;
        }


        if (Vector2.Distance(transform.position, destination2) < 0.4f && launched)
        {
            StartCoroutine(WaitBeforeDestroy());
        }
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage + gameManager.GetComponent<AttackStats>().attackDamage * attackDamage;
            collision.gameObject.GetComponent<EnemyGeneral>().projectileDirection = transform.position;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            {
                collision.gameObject.GetComponent<EnemyGeneral>().knockbackForce = knockbackForce + gameManager.GetComponent<AttackStats>().knockbackForce * knockbackForce;
                collision.gameObject.GetComponent<EnemyGeneral>().stun = true;
            }
        }
    }

    IEnumerator WaitBeforeDestroy()
    {
        GetComponent<Collider2D>().enabled = enabled;
        yield return new WaitForSecondsRealtime(0.025f);
        Destroy(gameObject);
    }
}
