using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DespawnExplosion : MonoBehaviour
{
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;
    private void Start()
    {
        StartCoroutine(Destroy());
    }

    IEnumerator Destroy()
    {
        yield return new WaitForSecondsRealtime(GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).length / 3);
        GetComponent<Collider2D>().enabled = true;
        yield return new WaitForSecondsRealtime(GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).length / 1.5f);
        Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage;
            collision.gameObject.GetComponent<EnemyGeneral>().projectileDirection = transform.position;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            {
                collision.gameObject.GetComponent<EnemyGeneral>().knockbackForce = knockbackForce;
                collision.gameObject.GetComponent<EnemyGeneral>().stun = true;
            }
        }
    }
}
