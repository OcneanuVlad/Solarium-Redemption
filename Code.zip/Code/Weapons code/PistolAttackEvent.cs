using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PistolAttackEvent : MonoBehaviour
{
    private Vector3 positionInCamera;
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;

    public GameObject gameManager;


    void Update()
    {
        positionInCamera = Camera.main.WorldToViewportPoint(transform.position);
        if (positionInCamera.x < -0.2f || positionInCamera.x > 1.2f || positionInCamera.y < -0.2 || positionInCamera.y > 1.2)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            collision.gameObject.GetComponent<EnemyGeneral>().projectileDirection = Vector2.zero;
            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage + gameManager.GetComponent<AttackStats>().attackDamage * attackDamage;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            {
                collision.gameObject.GetComponent<EnemyGeneral>().knockbackForce = knockbackForce + gameManager.GetComponent<AttackStats>().knockbackForce * knockbackForce;
                collision.gameObject.GetComponent<EnemyGeneral>().stun = true;
            }

            StartCoroutine(WaitBeforeDestroy());
        }
    }

    IEnumerator WaitBeforeDestroy()
    {
        GetComponent<Animator>().SetTrigger("Pop");
        GetComponent<Rigidbody2D>().velocity = Vector3.zero;
        GetComponent<Collider2D>().enabled = false;
        yield return new WaitForSecondsRealtime(GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).length);
        Destroy(gameObject);
    }
}
