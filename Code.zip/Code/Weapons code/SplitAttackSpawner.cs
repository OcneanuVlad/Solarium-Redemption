using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SplitAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public int projectilesNumber = 3;
    public float timeBetweenShots = 0.08f;

    private bool doneAttacking = false;
    public GameObject gameManager;
    private GameObject enemyToDamage;
    private float projectileRotation = 20;


    private void FixedUpdate()
    {
        if (!doneAttacking)
        {
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
            {
                StartCoroutine(LaunchProjectile());
            }
            else
            {
                gameManager.GetComponent<FindClosestEnemy>().FindEnemy();
            }
        }
    }

    IEnumerator LaunchProjectile()
    {
        doneAttacking = true;
        gameManager.GetComponent<FindClosestEnemy>().FindEnemy();

        if (gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length > 1)
        {
            int randomEnemy = Random.Range(0, gameManager.GetComponent<FindClosestEnemy>().allEnemies.Length);
            if (gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy] != null)
            {
                enemyToDamage = gameManager.GetComponent<FindClosestEnemy>().allEnemies[randomEnemy].gameObject;
                Vector2 direction = enemyToDamage.transform.position - transform.position;
                float angle = Mathf.Atan2(direction.y + 0.5f, direction.x) * Mathf.Rad2Deg;
                Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
                transform.rotation = rotation;

                for (int i = 1; i <= projectilesNumber + gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
                {
                    transform.Rotate(0, 0, projectileRotation);
                    GameObject instance = Instantiate(projectile, transform.position, transform.rotation);
                    instance.GetComponent<SplitAttackEvent>().attackDamage = attackDamage;
                    instance.GetComponent<SplitAttackEvent>().knockbackForce = knockbackForce;
                    instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
                    instance.GetComponent<Rigidbody2D>().velocity = instance.transform.right * projectileSpeed;
                    yield return new WaitForSeconds(timeBetweenShots);
                }
            }
        }

        yield return new WaitForSeconds(attackSpeed);
        doneAttacking = false;
    }
}

