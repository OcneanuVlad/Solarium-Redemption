using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightingAttackEvent : MonoBehaviour
{
    public void Start()
    {
        StartCoroutine(Destroy());
    }

    IEnumerator Destroy()
    {
        yield return new WaitForSecondsRealtime(GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).length);
        Destroy(gameObject);
    }
}
