using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinigunAttackEvent : MonoBehaviour
{
    private Vector3 positionInCamera;
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;
    [HideInInspector] public float lifetime;
    [HideInInspector] public bool decreaseSpeed;

    public GameObject gameManager;

    private void Start()
    {
        StartCoroutine(Destroy());
    }

    void Update()
    {
        positionInCamera = Camera.main.WorldToViewportPoint(transform.position);
        if (positionInCamera.x < -0.2f || positionInCamera.x > 1.2f || positionInCamera.y < -0.2 || positionInCamera.y > 1.2)
        {
            Destroy(gameObject);
        }
    }

    private void FixedUpdate()
    {
        if (decreaseSpeed)
        {
            GetComponent<Rigidbody2D>().velocity -= (GetComponent<Rigidbody2D>().velocity / 1.01f) * Time.deltaTime;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            collision.gameObject.GetComponent<EnemyGeneral>().projectileDirection = Vector2.zero;
            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage + gameManager.GetComponent<AttackStats>().attackDamage * attackDamage;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            {
                collision.gameObject.GetComponent<EnemyGeneral>().knockbackForce = knockbackForce + gameManager.GetComponent<AttackStats>().knockbackForce * knockbackForce;
                collision.gameObject.GetComponent<EnemyGeneral>().stun = true;
            }

        Destroy(gameObject);
        }
    }

    IEnumerator Destroy()
    {
        yield return new WaitForSeconds(lifetime);
        Destroy(gameObject);
    }
}
