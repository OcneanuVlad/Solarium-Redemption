using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteorAttackEvent : MonoBehaviour
{
    [HideInInspector] public Vector2 destination;
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float projectileSpeed;
    [HideInInspector] public float knockbackForce;
    [HideInInspector] public bool augmented;
    private new Rigidbody2D rigidbody;

    public GameObject explosion;
    public GameObject miniMeteor;

    [HideInInspector]public bool destroying = false;

    public GameObject gameManager;
    void Start()
    {

        rigidbody = GetComponent<Rigidbody2D>();
        rigidbody.velocity = (destination - (Vector2)transform.position).normalized * (projectileSpeed + gameManager.GetComponent<AttackStats>().projectileSpeed * projectileSpeed);

        Vector2 direction = destination - (Vector2)transform.position;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        transform.GetChild(0).transform.rotation = rotation;
    }

    private void FixedUpdate()
    {
        if (Vector2.Distance(transform.position, destination) < 0.2f && !destroying)
        {
            WaitBeforeDestroy();
        }
    }

    void WaitBeforeDestroy()
    {
        destroying = true;
        GameObject instance = Instantiate(explosion, transform.position, transform.rotation);
        instance.GetComponent<DespawnExplosion>().attackDamage = attackDamage;
        instance.transform.localScale = new Vector3(transform.localScale.x * 4, transform.localScale.x * 4);
        rigidbody.velocity = Vector2.zero;
        if (augmented)
        {
            for (int i = 1; i <= Random.Range(4, 8); i++)
            {
                SpawnMiniMeteor();
            }
        }
        Destroy(gameObject);
    }

    void SpawnMiniMeteor()
    {
        GameObject instance = Instantiate(miniMeteor, new Vector2(transform.position.x, transform.position.y - 0.5f), transform.rotation);
        instance.GetComponent<MiniMeteorAttackEvent>().attackDamage = attackDamage;
        instance.GetComponent<MiniMeteorAttackEvent>().knockbackForce = knockbackForce / 2;
        instance.GetComponent<MiniMeteorAttackEvent>().augmented = augmented;
        Vector2 randomPoint = Random.insideUnitCircle.normalized * transform.localScale.x * 1.5f;
        instance.GetComponent<MiniMeteorAttackEvent>().randomPoint = randomPoint;
        instance.GetComponent<MiniMeteorAttackEvent>().point2 = (Vector2)transform.position - new Vector2(0, 0.5f) + randomPoint;
    }
}
