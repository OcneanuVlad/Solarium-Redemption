using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightningChainAttackEvent : MonoBehaviour
{
    [HideInInspector] public Vector2 destinationToBe;
    [HideInInspector] public float attackDamage;
    [HideInInspector] public float knockbackForce;

    private void FixedUpdate()
    {
        if (Vector2.Distance(transform.position, destinationToBe) < 1)
        {
            StartCoroutine(Destroy());
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EnemyHitBox"))
        {
            collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth -= attackDamage;
            collision.gameObject.GetComponent<EnemyGeneral>().projectileDirection = Vector2.zero;
            if (collision.gameObject.GetComponent<EnemyGeneral>().currentEnemyHealth <= 0)
            {
                collision.gameObject.GetComponent<EnemyGeneral>().die = true;
            }
            else
            {
                collision.gameObject.GetComponent<EnemyGeneral>().knockbackForce = knockbackForce;
                collision.gameObject.GetComponent<EnemyGeneral>().stun = true;
            }
        }
    }

    IEnumerator Destroy()
    {
        GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezePositionY | RigidbodyConstraints2D.FreezeRotation | RigidbodyConstraints2D.FreezePositionX;
        GetComponent<Collider2D>().enabled = false;
        yield return new WaitForSeconds(0.2f);
        Destroy(gameObject);
    }
}
