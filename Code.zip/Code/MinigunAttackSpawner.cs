using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MinigunAttackSpawner : MonoBehaviour
{
    public GameObject projectile;
    public float attackSpeed;
    public float knockbackForce;
    public float attackDamage;
    public float projectileSpeed;
    public float timeBetweenBullets;
    public int projectileNumber;

    public Image sniperIcon;
    public Image minigunIcon;
    public Image shotgunIcon;

    public Sprite lit;
    public Sprite unlit;

    public bool augmented;

    private bool sniper;
    private bool shotgun;
    private bool minigun = true;

    private bool doneAttacking = false;
    public GameObject gameManager;

    public GameObject[] spawnPoints;

    void Update()
    {
        Vector2 direction = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        transform.rotation = rotation;

        if (augmented)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1))
            {
                sniper = true;
                shotgun = false;
                minigun = false;
                sniperIcon.sprite = lit;
                shotgunIcon.sprite = unlit;
                minigunIcon.sprite = unlit;
            }

            if (Input.GetKeyDown(KeyCode.Alpha2))
            {
                shotgun = false;
                minigun = true;
                sniper = false;
                sniperIcon.sprite = unlit;
                shotgunIcon.sprite = unlit;
                minigunIcon.sprite = lit;
            }

            if (Input.GetKeyDown(KeyCode.Alpha3))
            {
                shotgun = true;
                minigun = false;
                sniper = false;
                sniperIcon.sprite = unlit;
                shotgunIcon.sprite = lit;
                minigunIcon.sprite = unlit;
            }
        }
    }

    private void FixedUpdate()
    {
        if (minigun)
        {
            if (!doneAttacking)
            {
                StartCoroutine(LaunchProjectileMinigun());
            }
        }

        if (sniper)
        {
            if (!doneAttacking)
            {
                StartCoroutine(LaunchProjectileSniper());
            }
        }

        if (shotgun)
        {
            if (!doneAttacking)
            {
                StartCoroutine(LaunchProjectileShotgun());
            }
        }
    }

    IEnumerator LaunchProjectileMinigun()
    {
        doneAttacking = true;

        int i;
        for (i = 1; i <= projectileNumber + 2 * gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            GameObject instance = Instantiate(projectile, spawnPoints[Random.Range(0, 10)].transform.position, transform.rotation);
            instance.GetComponent<MinigunAttackEvent>().attackDamage = attackDamage;
            instance.GetComponent<MinigunAttackEvent>().lifetime = 2;
            instance.GetComponent<MinigunAttackEvent>().knockbackForce = knockbackForce;
            instance.GetComponent<Rigidbody2D>().velocity = instance.transform.right * (projectileSpeed + gameManager.GetComponent<AttackStats>().projectileSpeed * projectileSpeed);
            instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
            yield return new WaitForSeconds(timeBetweenBullets);
        }

        if (attackSpeed - gameManager.GetComponent<AttackStats>().attackSpeed * attackSpeed - (i * 0.15f) > 0.15f)
        {
            yield return new WaitForSeconds(attackSpeed - gameManager.GetComponent<AttackStats>().attackSpeed * attackSpeed - (i * timeBetweenBullets));
        }
        else
        {
            yield return new WaitForSeconds(timeBetweenBullets);
        }
        doneAttacking = false;
    }

    IEnumerator LaunchProjectileSniper()
    {
        doneAttacking = true;

        int i;
        for (i = 1; i <= 1 + gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            GameObject instance = Instantiate(projectile, transform.position, transform.rotation);
            instance.GetComponent<MinigunAttackEvent>().lifetime = 2;
            instance.GetComponent<MinigunAttackEvent>().attackDamage = attackDamage * 10;
            instance.GetComponent<MinigunAttackEvent>().knockbackForce = knockbackForce * 3;
            instance.GetComponent<Rigidbody2D>().velocity = instance.transform.right * (projectileSpeed * 2 + gameManager.GetComponent<AttackStats>().projectileSpeed * projectileSpeed);
            instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
            yield return new WaitForSeconds(0.35f);
        }
        yield return new WaitForSeconds(attackSpeed);

        doneAttacking = false;
    }

    IEnumerator LaunchProjectileShotgun()
    {
        doneAttacking = true;

        int i;
        for (i = 1; i <= projectileNumber * 4 + 2 * gameManager.GetComponent<AttackStats>().numberOfProjectiles; i++)
        {
            Vector3 q = transform.eulerAngles;
            GameObject instance = Instantiate(projectile, transform.position, Quaternion.Euler(0, 0, Random.Range(q.z + 30, q.z - 30)));
            instance.GetComponent<MinigunAttackEvent>().lifetime = 0.7f;
            instance.GetComponent<MinigunAttackEvent>().attackDamage = attackDamage;
            instance.GetComponent<MinigunAttackEvent>().knockbackForce = knockbackForce;
            instance.GetComponent<MinigunAttackEvent>().decreaseSpeed = true;
            instance.GetComponent<Rigidbody2D>().velocity = instance.transform.right * (projectileSpeed * 1.25f + gameManager.GetComponent<AttackStats>().projectileSpeed * projectileSpeed);
            instance.transform.localScale += new Vector3(gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.x, gameManager.GetComponent<AttackStats>().projectileSize / 100 * instance.transform.localScale.y, 0);
            if (i % 4 == 0)
            {
                yield return new WaitForEndOfFrame();
            }
        }
        yield return new WaitForSeconds(attackSpeed);

        doneAttacking = false;
    }
}

